import{x as i,k as tt,p as et,o as rt,W as at,i as f,n as g,r as c,a as x,E as l,b as d,c as I,t as w,e as P,d as U,f as ot}from"./vendor-DyfwM8PH.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))o(a);new MutationObserver(a=>{for(const s of a)if(s.type==="childList")for(const n of s.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&o(n)}).observe(document,{childList:!0,subtree:!0});function r(a){const s={};return a.integrity&&(s.integrity=a.integrity),a.referrerPolicy&&(s.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?s.credentials="include":a.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function o(a){if(a.ep)return;a.ep=!0;const s=r(a);fetch(a.href,s)}})();const st="https://func-agent-api-lf6kch3t2wm3e.azurewebsites.net";async function it(t){const e=t.apiUrl||st,r=await fetch(`${e}/api/chats/stream`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:t.messages,context:t.context||{}})});if(r.status>299||!r.ok){let o;try{o=await r.json()}catch{}const a=o?.error??r.statusText;throw new Error(a)}return ct(r)}class nt extends TransformStream{constructor(){let e;super({start(r){e=r},transform:r=>{const o=r.split(`
`).filter(Boolean);for(const a of o)try{this.buffer+=a,e.enqueue(JSON.parse(this.buffer)),this.buffer=""}catch{}}}),this.buffer=""}}async function*ct(t){const e=t.body?.pipeThrough(new TextDecoderStream).pipeThrough(new nt).getReader();if(!e)throw new Error("No response body or body is not readable");let r,o;for(;{value:r,done:o}=await e.read(),!o;)yield r}function lt(t,e=!0){if(t.role==="user")return{content:t.content,html:i`${t.content}`,followupQuestions:[],role:t.role,context:t.context};const r=[],o=t.content.replace(/<<([^>]+)>>/g,(s,n)=>(r.push(n),"")).split("<<")[0].trim();let a;if(e){const s=tt.parse(o,{async:!1,gfm:!0}),n=et.sanitize(s,{USE_PROFILES:{html:!0}});a=i`${rt(n)}`}else a=i`${o}`;return{content:o,html:a,followupQuestions:r,role:t.role,context:t.context}}class ${constructor(){this.listeners=new Map,this.isConnected=!1}static getInstance(){return $.instance||($.instance=new $),$.instance}async connect(e){if(!this.isConnected)try{const r="https://func-burger-api-lf6kch3t2wm3e.azurewebsites.net";this.client=new at({getClientAccessUrl:async()=>{const o=await fetch(`${r}/api/realtime/negotiate?userId=${e}`);if(!o.ok){if(o.status===503)return console.warn("Real-time features disabled (Server returned 503)"),"";throw new Error(`Failed to negotiate realtime connection: ${o.statusText}`)}const a=await o.json();if(!a.url)throw new Error("No URL returned from negotiate");return a.url}}),this.client.on("server-message",o=>{const s=o.message.data;s&&s.event&&this.emit(s.event,s.data)}),await this.client.start(),this.isConnected=!0,console.log("Real-time connection established")}catch(r){console.warn("Real-time service unavailable, falling back to polling/static updates.",r),this.isConnected=!1}}on(e,r){this.listeners.has(e)||this.listeners.set(e,[]),this.listeners.get(e)?.push(r)}off(e,r){const o=this.listeners.get(e);o&&this.listeners.set(e,o.filter(a=>a!==r))}emit(e,r){const o=this.listeners.get(e);o&&o.forEach(a=>a(r))}}const V='<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M5.69362 11.9997L2.29933 3.2715C2.0631 2.66403 2.65544 2.08309 3.2414 2.28959L3.33375 2.32885L21.3337 11.3288C21.852 11.588 21.8844 12.2975 21.4309 12.6129L21.3337 12.6705L3.33375 21.6705C2.75077 21.962 2.11746 21.426 2.2688 20.8234L2.29933 20.7278L5.69362 11.9997L2.29933 3.2715L5.69362 11.9997ZM4.4021 4.54007L7.01109 11.2491L13.6387 11.2497C14.0184 11.2497 14.3322 11.5318 14.3818 11.8979L14.3887 11.9997C14.3887 12.3794 14.1065 12.6932 13.7404 12.7428L13.6387 12.7497L7.01109 12.7491L4.4021 19.4593L19.3213 11.9997L4.4021 4.54007Z"></path></svg>',dt='<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C10.3817 22 8.81782 21.6146 7.41286 20.888L3.58704 21.9553C2.92212 22.141 2.23258 21.7525 2.04691 21.0876C1.98546 20.8676 1.98549 20.6349 2.04695 20.4151L3.11461 16.5922C2.38637 15.186 2 13.6203 2 12C2 6.47715 6.47715 2 12 2ZM12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 13.4696 3.87277 14.8834 4.57303 16.1375L4.72368 16.4072L3.61096 20.3914L7.59755 19.2792L7.86709 19.4295C9.12006 20.1281 10.5322 20.5 12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5ZM12 15.5C12.5523 15.5 13 15.9477 13 16.5C13 17.0523 12.5523 17.5 12 17.5C11.4477 17.5 11 17.0523 11 16.5C11 15.9477 11.4477 15.5 12 15.5ZM12 6.75C13.5188 6.75 14.75 7.98122 14.75 9.5C14.75 10.5108 14.4525 11.074 13.6989 11.8586L13.5303 12.0303C12.9084 12.6522 12.75 12.9163 12.75 13.5C12.75 13.9142 12.4142 14.25 12 14.25C11.5858 14.25 11.25 13.9142 11.25 13.5C11.25 12.4892 11.5475 11.926 12.3011 11.1414L12.4697 10.9697C13.0916 10.3478 13.25 10.0837 13.25 9.5C13.25 8.80964 12.6904 8.25 12 8.25C11.3528 8.25 10.8205 8.74187 10.7565 9.37219L10.75 9.5C10.75 9.91421 10.4142 10.25 10 10.25C9.58579 10.25 9.25 9.91421 9.25 9.5C9.25 7.98122 10.4812 6.75 12 6.75Z"></path></svg>',pt='<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C17.5228 2 22 6.47715 22 12C22 12.2628 21.9899 12.5232 21.97 12.7809C21.5319 12.3658 21.0361 12.0111 20.4958 11.73C20.3532 7.16054 16.6041 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 13.4696 3.87277 14.8834 4.57303 16.1375L4.72368 16.4072L3.61096 20.3914L7.59755 19.2792L7.86709 19.4295C9.04305 20.0852 10.3592 20.4531 11.73 20.4958C12.0111 21.0361 12.3658 21.5319 12.7809 21.97C12.5232 21.9899 12.2628 22 12 22C10.3817 22 8.81782 21.6146 7.41286 20.888L3.58704 21.9553C2.92212 22.141 2.23258 21.7525 2.04691 21.0876C1.98546 20.8676 1.98549 20.6349 2.04695 20.4151L3.11461 16.5922C2.38637 15.186 2 13.6203 2 12C2 6.47715 6.47715 2 12 2ZM23 17.5C23 14.4624 20.5376 12 17.5 12C14.4624 12 12 14.4624 12 17.5C12 20.5376 14.4624 23 17.5 23C20.5376 23 23 20.5376 23 17.5ZM18.0006 18L18.0011 20.5035C18.0011 20.7797 17.7773 21.0035 17.5011 21.0035C17.225 21.0035 17.0011 20.7797 17.0011 20.5035L17.0006 18H14.4956C14.2197 18 13.9961 17.7762 13.9961 17.5C13.9961 17.2239 14.2197 17 14.4956 17H17.0005L17 14.4993C17 14.2231 17.2239 13.9993 17.5 13.9993C17.7761 13.9993 18 14.2231 18 14.4993L18.0005 17H20.4966C20.7725 17 20.9961 17.2239 20.9961 17.5C20.9961 17.7762 20.7725 18 20.4966 18H18.0006Z"></path></svg>',ht=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.54541 2C7.99668 2 6.66956 3.10758 6.39252 4.63133L6.35458 4.83999L6.2571 4.85499C4.38145 5.14355 2.99688 6.75743 2.99688 8.65514V9.25C2.99688 10.1676 3.37719 10.9965 3.9888 11.5874C2.79699 12.3062 2 13.6132 2 15.1065C2 17.0869 3.41345 18.7852 5.36095 19.1447L5.37475 19.1472C5.78266 20.8178 7.28119 22 9.00888 22C10.2316 22 11.3173 21.4134 12 20.5063C12.6827 21.4134 13.7684 22 14.9911 22C16.7188 22 18.2173 20.8178 18.6252 19.1472L18.6391 19.1447C20.5866 18.7852 22 17.0869 22 15.1065C22 13.6124 21.2021 12.3048 20.0093 11.5863C20.6202 10.9954 21 10.167 21 9.25V8.65514C21 6.75743 19.6154 5.14355 17.7398 4.85499L17.6423 4.83999L17.6044 4.63133C17.3273 3.10758 16.0002 2 14.4515 2C13.467 2 12.5863 2.44389 11.9984 3.14243C11.4106 2.44389 10.5298 2 9.54541 2ZM12.75 15.5V5.20459C12.75 5.17646 12.7496 5.14841 12.7489 5.12045C12.7928 4.21812 13.5383 3.5 14.4515 3.5C15.2753 3.5 15.9812 4.08915 16.1286 4.89966L16.2621 5.63416C16.3193 5.94886 16.5698 6.19264 16.886 6.24128L17.5117 6.33755C18.6556 6.51353 19.5 7.49778 19.5 8.65514V9.25C19.5 10.2165 18.7165 11 17.75 11H17.437C17.4781 10.8402 17.5 10.6726 17.5 10.5C17.5 9.39543 16.6046 8.5 15.5 8.5C14.3954 8.5 13.5 9.39543 13.5 10.5C13.5 11.3393 14.017 12.0579 14.75 12.3546V14.25C14.75 14.9404 14.1904 15.5 13.5 15.5H12.75ZM16.25 12.3546C16.2622 12.3497 16.2743 12.3447 16.2863 12.3395C16.4139 12.44 16.5749 12.5 16.75 12.5H17.8935C19.333 12.5 20.5 13.667 20.5 15.1065C20.5 16.3635 19.6029 17.4414 18.3667 17.6696L17.8638 17.7625C17.5668 17.8173 17.3316 18.045 17.2672 18.3401L17.1807 18.7366C16.9561 19.766 16.0448 20.5 14.9911 20.5C13.7534 20.5 12.75 19.4966 12.75 18.2589V17H13.5C15.0188 17 16.25 15.7688 16.25 14.25V12.3546ZM11.248 5.12045C11.2472 5.14841 11.2469 5.17646 11.2469 5.20459V7.2C11.2469 7.22323 11.2479 7.24622 11.25 7.26892V8H10.437C10.215 7.13739 9.43192 6.5 8.5 6.5C7.39543 6.5 6.5 7.39543 6.5 8.5C6.5 9.60457 7.39543 10.5 8.5 10.5C9.24028 10.5 9.88663 10.0978 10.2324 9.5H11.25L11.25 18.2589C11.25 19.4966 10.2466 20.5 9.00888 20.5C7.95523 20.5 7.04387 19.766 6.81927 18.7366L6.73276 18.3401C6.66837 18.045 6.43321 17.8173 6.13616 17.7625L5.63327 17.6696C4.39715 17.4414 3.5 16.3635 3.5 15.1065C3.5 13.667 4.66696 12.5 6.10647 12.5H7.25C7.52614 12.5 7.75 12.7239 7.75 13V13.6454C7.01704 13.9421 6.5 14.6607 6.5 15.5C6.5 16.6046 7.39543 17.5 8.5 17.5C9.60457 17.5 10.5 16.6046 10.5 15.5C10.5 14.6607 9.98296 13.9421 9.25 13.6454V13C9.25 11.8954 8.35457 11 7.25 11H6.24687C5.28038 11 4.49688 10.2165 4.49688 9.25V8.65514C4.49688 7.49778 5.34129 6.51353 6.48518 6.33755L7.11092 6.24128C7.42706 6.19264 7.67756 5.94886 7.73478 5.63416L7.86832 4.89966C8.01569 4.08915 8.72161 3.5 9.54541 3.5C10.4586 3.5 11.2041 4.21812 11.248 5.12045ZM8.5 8C8.77614 8 9 8.22386 9 8.5C9 8.77614 8.77614 9 8.5 9C8.22386 9 8 8.77614 8 8.5C8 8.22386 8.22386 8 8.5 8ZM8 15.5C8 15.2239 8.22386 15 8.5 15C8.77614 15 9 15.2239 9 15.5C9 15.7761 8.77614 16 8.5 16C8.22386 16 8 15.7761 8 15.5ZM15.5 10C15.7761 10 16 10.2239 16 10.5C16 10.7761 15.7761 11 15.5 11C15.2239 11 15 10.7761 15 10.5C15 10.2239 15.2239 10 15.5 10Z"/></svg>
`;var ut=Object.defineProperty,gt=Object.getOwnPropertyDescriptor,F=(t,e,r,o)=>{for(var a=o>1?void 0:o?gt(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&ut(e,r,a),a};let y=class extends x{constructor(){super(...arguments),this.isExpanded=!1,this.expandedSteps=new Set,this.expandedOutputs=new Set}toggleExpanded(){this.isExpanded=!this.isExpanded}toggleStepExpanded(t){this.expandedSteps=this.expandedSteps.has(t)?new Set([...this.expandedSteps].filter(e=>e!==t)):new Set([...this.expandedSteps,t])}toggleOutputExpanded(t,e){const r=`${t}-${e}`;this.expandedOutputs=this.expandedOutputs.has(r)?new Set([...this.expandedOutputs].filter(o=>o!==r)):new Set([...this.expandedOutputs,r])}getStepType(t){return t.type}getStepSummary(t){return t.type==="tool"?`Tool: ${t.name}`:`LLM: ${t.name}`}truncateText(t,e=100){return t.length<=e?t:t.slice(0,Math.max(0,e))+"..."}renderDetailSection(t,e,r,o,a=!1){const s=`${r}-${o}`,n=this.expandedOutputs.has(s),K=a&&!n?this.truncateText(e,500):e;return i`
      <div class="detail-section">
        <div class="detail-header">
          <h4>${t}</h4>
          ${a?i`
                <div class="detail-actions">
                  <button
                    class="action-button expand-button"
                    @click=${()=>{this.toggleOutputExpanded(r,o)}}
                    title=${n?"Show less":"Show full content"}
                  >
                    ${n?"Less":"More"}
                  </button>
                </div>
              `:l}
        </div>
        <pre class="detail-content">${K}</pre>
      </div>
    `}renderStep(t,e){const r=this.getStepType(t),o=this.expandedSteps.has(e),a=this.getStepSummary(t);return i`
      <div class="step ${r}">
        <div class="step-content">
          <button
            class="step-header"
            @click=${()=>{this.toggleStepExpanded(e)}}
            aria-expanded=${o}
          >
            <div class="step-indicator ${r}">${r==="tool"?"T":"L"}</div>
            <div class="step-summary">
              <span class="step-title">${a}</span>
            </div>
            <div class="step-toggle ${o?"expanded":""}">▼</div>
          </button>

          ${o?i`
                <div class="step-details">
                  ${t.input===void 0?l:this.renderDetailSection("Input",t.input,e,"input",t.input.length>500)}
                  ${t.output===void 0?l:this.renderDetailSection("Output",t.output,e,"output",t.output.length>500)}
                </div>
              `:l}
        </div>
      </div>
    `}render(){const t=this.message?.context?.intermediateSteps??[];return t.length===0?l:i`
          <div class="debug-container">
            <button
              class="debug-toggle ${this.isExpanded?"expanded":""}"
              @click=${this.toggleExpanded}
              aria-expanded=${this.isExpanded}
            >
              <span class="toggle-icon"> ${d(ht)} </span>
              ${this.isExpanded?"Hide intermediate steps":"Show intermediate steps"} (${t.length})
            </button>

            ${this.isExpanded?i`
                  <div class="steps-timeline">
                    ${I(t,(e,r)=>r,(e,r)=>this.renderStep(e,r))}
                  </div>
                `:l}
          </div>
        `}};y.styles=f`
    :host {
      /* Base properties */
      --primary: var(--azc-primary, #07f);
      --bg: var(--azc-bg, #eee);
      --error: var(--azc-error, #e30);
      --text-color: var(--azc-text-color, #000);
      --space-md: var(--azc-space-md, 12px);
      --space-xl: var(--azc-space-xl, calc(var(--space-md) * 2));
      --space-xs: var(--azc-space-xs, calc(var(--space-md) / 2));
      --space-xxs: var(--azc-space-xs, calc(var(--space-md) / 4));
      --border-radius: var(--azc-border-radius, 16px);
      --focus-outline: var(--azc-focus-outline, 2px solid);
      --overlay-color: var(--azc-overlay-color, rgba(0 0 0 / 40%));

      /* Component-specific properties */
      --card-bg: var(--azc-card-bg, #fff);
      --border-color: var(--azc-border-color, #ccc);

      display: contents;
    }

    *:focus-visible {
      outline: var(--focus-outline) var(--primary);
    }

    svg {
      fill: currentColor;
      width: 100%;
    }

    button {
      font-family: inherit;
      font-size: inherit;
      border: none;
      background: none;
      cursor: pointer;
      border-radius: calc(var(--border-radius) / 2);
      outline: var(--focus-outline) transparent;
      transition: all 0.2s ease;
    }

    .debug-container {
      width: 100%;
    }

    .debug-toggle {
      display: flex;
      align-items: center;
      gap: var(--space-xs);
      padding: calc(var(--space-xs) / 2) var(--space-xs);
      background: color-mix(in srgb, var(--text-color), transparent 95%);
      border: none;
      border-radius: calc(var(--border-radius) / 4);
      color: color-mix(in srgb, var(--text-color), transparent 30%);
      font-size: 0.75rem;
      font-weight: 500;
      text-align: left;
      transition: all 0.2s ease;

      &:hover {
        background: color-mix(in srgb, var(--text-color), transparent 90%);
        color: var(--text-color);
      }

      &.expanded {
        color: var(--text-color);
      }
    }

    .toggle-icon {
      display: contents;
      svg {
        width: 1rem;
        height: 1rem;
      }
    }

    .toggle-arrow {
      transition: transform 0.2s ease;
      opacity: 0.6;
      font-size: 0.8rem;

      &.expanded {
        transform: rotate(180deg);
      }
    }

    .steps-timeline {
      margin-top: var(--space-md);
      position: relative;
    }

    .step {
      position: relative;
      margin-bottom: var(--space-md);

      &:last-child {
        margin-bottom: 0;
      }
    }

    .step-content {
      position: relative;
    }

    .step-header {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      padding: var(--space-xs) var(--space-md);
      background: color-mix(in srgb, var(--card-bg), var(--text-color) 2%);
      border: 1px solid var(--border-color);
      border-radius: calc(var(--border-radius) / 2);
      width: 100%;
      text-align: left;
      transition: background-color 0.2s ease;

      &:hover {
        background: color-mix(in srgb, var(--card-bg), var(--text-color) 4%);
      }

      &[aria-expanded='true'] {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom-color: transparent;
      }
    }

    .step-indicator {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      font-weight: 600;
      color: white;

      &.tool {
        background: var(--primary);
      }

      &.llm {
        background: oklch(from var(--primary) l c calc(h + 180));
      }
    }

    .step-summary {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .step-title {
      font-weight: 500;
      color: var(--text-color);
    }

    .step-toggle {
      transition: transform 0.2s ease;
      opacity: 0.6;
      font-size: 0.7rem;

      &.expanded {
        transform: rotate(180deg);
      }
    }

    .step-details {
      background: var(--card-bg);
      border: 1px solid var(--border-color);
      border-top: none;
      border-radius: 0 0 calc(var(--border-radius) / 2) calc(var(--border-radius) / 2);
      padding: var(--space-md);
      margin-top: -1px;
    }

    .detail-section {
      margin-bottom: var(--space-md);

      &:last-child {
        margin-bottom: 0;
      }
    }

    .detail-section h4 {
      margin: 0 0 var(--space-xs) 0;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--primary);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .detail-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--space-xs);
    }

    .detail-actions {
      display: flex;
      gap: var(--space-xs);
    }

    .action-button {
      padding: calc(var(--space-xs) / 2) var(--space-xs);
      font-size: 0.7rem;
      font-weight: 500;
      color: var(--primary);
      background: color-mix(in srgb, var(--primary), transparent 90%);
      border: 1px solid color-mix(in srgb, var(--primary), transparent 70%);
      border-radius: calc(var(--border-radius) / 4);
      transition: all 0.2s ease;

      &:hover {
        background: color-mix(in srgb, var(--primary), transparent 80%);
        border-color: color-mix(in srgb, var(--primary), transparent 50%);
      }

      &:active {
        transform: translateY(1px);
      }
    }

    .detail-content {
      background: color-mix(in srgb, var(--card-bg), var(--text-color) 3%);
      border: 1px solid var(--border-color);
      border-radius: calc(var(--border-radius) / 4);
      padding: var(--space-xs);
      margin: 0;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace;
      font-size: 0.75rem;
      line-height: 1.4;
      overflow-x: auto;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .loader-animation {
      position: absolute;
      width: 100%;
      height: 2px;
      overflow: hidden;
      background-color: var(--primary);
      transform: scaleX(0);
      transform-origin: center left;
      animation: cubic-bezier(0.85, 0, 0.15, 1) 2s infinite load-animation;
    }

    @keyframes load-animation {
      0% {
        transform: scaleX(0);
        transform-origin: center left;
      }
      50% {
        transform: scaleX(1);
        transform-origin: center left;
      }
      51% {
        transform: scaleX(1);
        transform-origin: center right;
      }
      100% {
        transform: scaleX(0);
        transform-origin: center right;
      }
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none;
        transition: none;
      }
    }
  `;F([g({type:Object})],y.prototype,"message",2);F([c()],y.prototype,"isExpanded",2);F([c()],y.prototype,"expandedSteps",2);F([c()],y.prototype,"expandedOutputs",2);y=F([w("azc-debug")],y);var bt=Object.defineProperty,vt=Object.getOwnPropertyDescriptor,h=(t,e,r,o)=>{for(var a=o>1?void 0:o?vt(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&bt(e,r,a),a};const mt='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>',Z={apiUrl:"",enablePromptSuggestions:!0,enableMarkdown:!0,enableDebug:!0,minStepDisplayMs:1e3,promptSuggestions:["What promos are available today?","Order a double cheeseburger for delivery","Track my order status"],messages:[],strings:{promptSuggestionsTitle:"Ask Chicha about burgers & deals",citationsTitle:"Citations:",followUpQuestionsTitle:"Suggested follow-up:",chatInputPlaceholder:"Type your order or question...",chatInputButtonLabel:"Send question",assistant:"Chicha AI",user:"You",errorMessage:"Oops, I dropped the ketchup. Please try again.",newChatButton:"New chat",retryButton:"Retry",tools:{get_burgers:"Scanning menu...",get_burger_by_id:"Checking burger details...",get_toppings:"Looking for toppings...",get_topping_by_id:"Checking topping details...",get_topping_categories:"Checking categories...",get_orders:"Tracking orders...",get_order_by_id:"Locating order...",place_order:"Placing your delicious order...",delete_order_by_id:"Cancelling order...",search_nearby_restaurants:"Checking Uber Eats for nearby spots..."}}};let p=class extends x{constructor(){super(...arguments),this.options=Z,this.question="",this.messages=[],this.userId="",this.sessionId="",this.hasError=!1,this.isLoading=!1,this.isStreaming=!1,this.isGettingLocation=!1,this.toastMessage=null,this.lastStepSetAt=0,this.stepQueue=[],this.renderSuggestions=t=>i`
    <section class="suggestions-container">
      <h2>${this.options.strings.promptSuggestionsTitle}</h2>
      <div class="suggestions">
        ${U(t,e=>i`
            <button class="suggestion" @click=${async()=>{await this.onSuggestionClicked(e)}}>
              ${e}
            </button>
        `)}
      </div>
    </section>
  `,this.renderLoader=()=>this.isLoading&&!this.isStreaming?i`
          <div class="message assistant loader">
            <div class="message-body">
              ${this.currentStep?i`<div class="current-step">${this.getCurrentStepTitle()}</div>`:l}
              <slot name="loader"><div class="loader-animation"></div></slot>
              <div class="message-role">${this.options.strings.assistant}</div>
            </div>
          </div>
        `:l,this.renderMessage=t=>i`
    <div class="message ${t.role} animation">
      ${t.role==="assistant"?i`<slot name="message-header"></slot>`:l}
      <div class="message-body">
        ${t.role==="assistant"&&this.options.enableDebug?i`<azc-debug .message=${t}></azc-debug>`:l}
        <div class="content ${this.isStreaming?"streaming":""}">${t.html}</div>
      </div>
      <div class="message-role">
        ${t.role==="user"?this.options.strings.user:this.options.strings.assistant}
      </div>
    </div>
  `,this.renderError=()=>i`
    <div class="message assistant error">
      <div class="message-body">
        <span class="error-message">${this.options.strings.errorMessage}</span>
        <button @click=${async()=>this.onSendClicked(!0)}>${this.options.strings.retryButton}</button>
      </div>
    </div>
  `,this.renderFollowupQuestions=t=>t.length>0?i`
          <div class="questions">
            <span class="question-icon" title=${this.options.strings.followUpQuestionsTitle}>
              ${d(dt)} </span
            >${U(t,e=>i`
                <button class="question animation" @click=${async()=>{await this.onSuggestionClicked(e)}}>
                  ${e}
                </button>
            `)}
          </div>
        `:l,this.renderChatInput=()=>i`
    <div class="chat-input">
      <button
        class="button new-chat-button"
        @click=${()=>{this.onNewChatClicked()}}
        title=${this.options.strings.newChatButton}
        .disabled=${this.messages?.length===0||this.isLoading||this.isStreaming}
      >
        ${d(pt)}
      </button>
      <form class="input-form">
        <button
          class="location-button ${this.userLocation?"active":""} ${this.isGettingLocation?"loading":""}"
          type="button"
          @click=${()=>this.onLocationClicked()}
          title="Share your location"
          .disabled=${this.isLoading}
        >
          ${d(mt)}
        </button>
        <textarea
          class="text-input"
          placeholder="${this.options.strings.chatInputPlaceholder}"
          .value=${this.question}
          autocomplete="off"
          @input=${t=>{this.question=t.target.value}}
          @keypress=${this.onKeyPressed}
          .disabled=${this.isLoading}
        ></textarea>
        <button
          class="submit-button"
          @click=${async()=>this.onSendClicked()}
          title="${this.options.strings.chatInputButtonLabel}"
          .disabled=${this.isLoading||!this.question}
        >
          ${d(V)}
        </button>
      </form>
    </div>
  `}async updated(t){if(super.updated(t),t.has("userId")&&this.userId){const e=$.getInstance();await e.connect(this.userId),e.on("order-created",r=>{this.showToast(`🎉 Order #${r.id.slice(-6)} Confirmed!`)}),e.on("order-update",r=>{const o=r.status.replace("-"," ").toUpperCase();this.showToast(`🚚 Order #${r.id.slice(-6)} update: ${o}`)})}}showToast(t){this.toastMessage=t,this.toastTimer&&clearTimeout(this.toastTimer),this.toastTimer=window.setTimeout(()=>{this.toastMessage=null},4e3)}async onSuggestionClicked(t){this.question=t,await this.onSendClicked()}onNewChatClicked(){this.messages=[],this.sessionId="",this.fireMessagesUpdatedEvent()}async onKeyPressed(t){t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),await this.onSendClicked())}async onLocationClicked(){if(this.userLocation){this.userLocation=void 0,this.showToast("📍 Location sharing disabled");return}this.isGettingLocation=!0,"geolocation"in navigator?navigator.geolocation.getCurrentPosition(t=>{this.userLocation={lat:t.coords.latitude,long:t.coords.longitude},this.isGettingLocation=!1,this.showToast("📍 Location acquired! Ready to find food.")},t=>{console.error("Error getting location",t),this.isGettingLocation=!1,this.showToast("⚠️ Could not get location. Check permissions.")}):(this.isGettingLocation=!1,this.showToast("⚠️ Geolocation not supported."))}async onSendClicked(t=!1){if(!(this.isLoading||!this.question&&!t)){this.hasError=!1,t||(this.messages=[...this.messages,{content:this.question,role:"user"}]),this.question="",this.isLoading=!0,this.currentStep=void 0,this.stepQueue=[],this.stepTimer&&(clearTimeout(this.stepTimer),this.stepTimer=void 0),this.scrollToLastMessage();try{const e=await it({...this.options,messages:this.messages,context:{userId:this.userId,sessionId:this.sessionId,location:this.userLocation}}),{messages:r}=this,o={content:"",role:"assistant",context:{intermediateSteps:[]}};for await(const a of e){a.delta.content?(this.isStreaming=!0,o.content+=a.delta.content,this.messages=[...r,o]):a.delta.context?.intermediateSteps?o.context.intermediateSteps=[...o.context.intermediateSteps,...a.delta.context.intermediateSteps]:a.delta.context?.currentStep&&this.updateCurrentStep(a.delta.context.currentStep);const s=a.context?.sessionId;!this.sessionId&&s&&(this.sessionId=s)}this.isLoading=!1,this.isStreaming=!1,this.fireMessagesUpdatedEvent()}catch(e){this.hasError=!0,this.isLoading=!1,this.isStreaming=!1,console.error(e)}}}updateCurrentStep(t){const e=this.options.minStepDisplayMs??500,r=Date.now(),o=r-this.lastStepSetAt;if(!this.currentStep||o>=e){this.currentStep=t,this.lastStepSetAt=r;return}this.stepQueue.push(t),this.scheduleNextStep(e)}scheduleNextStep(t){if(this.stepTimer||this.stepQueue.length===0)return;const e=Date.now()-this.lastStepSetAt,r=Math.max(0,t-e);this.stepTimer=window.setTimeout(()=>{if(this.stepTimer=void 0,this.stepQueue.length>0){const o=this.stepQueue.shift();this.currentStep=o,this.lastStepSetAt=Date.now()}this.stepQueue.length>0&&this.scheduleNextStep(t)},r)}disconnectedCallback(){this.stepTimer&&clearTimeout(this.stepTimer),this.toastTimer&&clearTimeout(this.toastTimer),this.stepQueue=[],super.disconnectedCallback()}requestUpdate(t,e){if(t==="messages")this.scrollToLastMessage();else if(t==="hasError"||t==="isLoading"||t==="isStreaming"){const r={hasError:this.hasError,isLoading:this.isLoading,isStreaming:this.isStreaming},o=new CustomEvent("stateChanged",{detail:{state:r},bubbles:!0});this.dispatchEvent(o)}super.requestUpdate(t,e)}fireMessagesUpdatedEvent(){const t=new CustomEvent("messagesUpdated",{detail:{messages:this.messages},bubbles:!0});this.dispatchEvent(t)}scrollToLastMessage(){setTimeout(()=>{const{bottom:t}=this.messagesElement.getBoundingClientRect(),{top:e}=this.chatInputElement.getBoundingClientRect();t>e&&this.chatContainerElement.scrollBy(0,t-e)},0)}getCurrentStepTitle(){if(!this.currentStep)return"";switch(this.currentStep.type){case"llm":return"Thinking...";case"tool":return`${this.options.strings.tools[this.currentStep.name]??this.currentStep.name}...`;default:return""}}render(){const t=this.messages.map(e=>lt(e,this.options.enableMarkdown));return i`
      <section class="chat-container">
        ${this.options.enablePromptSuggestions&&this.options.promptSuggestions.length>0&&this.messages.length===0?this.renderSuggestions(this.options.promptSuggestions):l}
        <div class="messages">
          ${I(t,(e,r)=>r,this.renderMessage)} ${this.renderLoader()}
          ${this.hasError?this.renderError():l}
          ${this.renderFollowupQuestions(t[t.length-1]?.followupQuestions??[])}
        </div>
        ${this.renderChatInput()}
        
        <div class="toast-notification ${this.toastMessage?"show":""}">
            ${this.toastMessage}
        </div>
      </section>
    `}};p.styles=f`
    :host {
      /* Base properties */
      --primary: var(--azc-primary, #07f);
      --error: var(--azc-error, #e30);
      --text-color: var(--azc-text-color, #000);
      --text-invert-color: var(--azc--text-invert-color, #fff);
      --disabled-color: var(--azc-disabled-color, #ccc);
      --bg: var(--azc-bg, #eee);
      --border-color: var(--azc-border-color, #ccc);
      --card-bg: var(--azc-card-bg, #fff);
      --card-shadow: var(--azc-card-shadow, 0 0.3px 0.9px rgba(0 0 0 / 12%), 0 1.6px 3.6px rgba(0 0 0 / 16%));
      --space-md: var(--azc-space-md, 12px);
      --space-xl: var(--azc-space-xl, calc(var(--space-md) * 2));
      --space-xxs: var(--azc-space-xs, calc(var(--space-md) / 2));
      --space-xxs: var(--azc-space-xs, calc(var(--space-md) / 4));
      --border-radius: var(--azc-border-radius, 16px);
      --focus-outline: var(--azc-focus-outline, 2px solid);
      --overlay-color: var(--azc-overlay-color, rgba(0 0 0 / 40%));

      /* Component-specific properties */
      --error-color: var(--azc-error-color, var(--error));
      --error-border: var(--azc-error-border, none);
      --error-bg: var(--azc-error-bg, var(--card-bg));
      --retry-button-color: var(--azc-retry-button-color, var(--text-color));
      --retry-button-bg: var(--azc-retry-button-bg, #f0f0f0);
      --retry-button-bg-hover: var(--azc-retry-button-bg, #e5e5e5);
      --retry-button-border: var(--azc-retry-button-border, none);
      --suggestion-color: var(--azc-suggestion-color, var(--text-color));
      --suggestion-border: var(--azc-suggestion-border, none);
      --suggestion-bg: var(--azc-suggestion-bg, var(--card-bg));
      --suggestion-shadow: var(--azc-suggestion-shadow, 0 6px 16px -1.5px rgba(141 141 141 / 30%));
      --user-message-color: var(--azc-user-message-color, var(--text-invert-color));
      --user-message-border: var(--azc-user-message-border, none);
      --user-message-bg: var(--azc-user-message-bg, var(--primary));
      --bot-message-color: var(--azc-bot-message-color, var(--text-color));
      --bot-message-border: var(--azc-bot-message-border, none);
      --citation-color: var(--azc-citation-color, var(--text-invert-color));
      --bot-message-bg: var(--azc-bot-message-bg, var(--card-bg));
      --citation-bg: var(--azc-citation-bg, var(--primary));
      --citation-bg-hover: var(--azc-citation-bg, color-mix(in srgb, var(--primary), #000 10%));
      --new-chat-button-color: var(--azc-button-color, var(--text-invert-color));
      --new-chat-button-bg: var(--azc-new-chat-button-bg, var(--primary));
      --new-chat-button-bg-hover: var(--azc-new-chat-button-bg, color-mix(in srgb, var(--primary), #000 10%));
      --chat-input-color: var(--azc-chat-input-color, var(--text-color));
      --chat-input-border: var(--azc-chat-input-border, none);
      --chat-input-bg: var(--azc-chat-input-bg, var(--card-bg));
      --submit-button-color: var(--azc-button-color, var(--primary));
      --submit-button-border: var(--azc-submit-button-border, none);
      --submit-button-bg: var(--azc-submit-button-bg, none);
      --submit-button-bg-hover: var(--azc-submit-button-color, #f0f0f0);

      container-type: size;
    }
    *:focus-visible {
      outline: var(--focus-outline) var(--primary);
    }
    .animation {
      animation: 0.3s ease;
    }
    svg {
      fill: currentColor;
      width: 100%;
    }
    button {
      font-size: 1rem;
      border-radius: calc(var(--border-radius) / 2);
      outline: var(--focus-outline) transparent;
      transition: outline 0.3s ease;

      &:not(:disabled) {
        cursor: pointer;
      }
    }
    .chat-container {
      height: 100%;
      overflow: auto;
      container-type: inline-size;
      position: relative;
      background: var(--bg);
      font-family:
        'Segoe UI',
        -apple-system,
        BlinkMacSystemFont,
        Roboto,
        'Helvetica Neue',
        sans-serif;
      display: flex;
      flex-direction: column;
    }
    .suggestions-container {
      text-align: center;
      padding: var(--space-xl);
      margin-top: auto;
      margin-bottom: auto;
    }
    .suggestions {
      display: flex;
      gap: var(--space-md);
    }
    @container (width < 480px) {
      .suggestions {
        flex-direction: column;
      }
    }

    .suggestion {
      flex: 1 1 0;
      padding: var(--space-xl) var(--space-md);
      color: var(--sugestion-color);
      background: var(--suggestion-bg);
      border: var(--suggestion-border);
      border-radius: var(--border-radius);
      box-shadow: var(--suggestion-shadow);
      font-weight: 500;
      transition: transform 0.2s;

      &:hover {
        outline: var(--focus-outline) var(--primary);
        transform: translateY(-3px);
      }
    }
    .messages {
      padding: var(--space-xl);
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
      flex: 1;
      overflow-y: auto;
    }
    .user {
      align-self: end;
      color: var(--user-message-color);
      background: var(--user-message-bg);
      border: var(--user-message-border);
    }
    .assistant {
      color: var(--bot-message-color);
      background: var(--bot-message-bg);
      border: var(--bot-message-border);
      box-shadow: var(--card-shadow);
    }
    .message {
      position: relative;
      width: auto;
      max-width: 70%;
      border-radius: var(--border-radius);
      padding: var(--space-xl);
      margin-bottom: var(--space-xl);

      &.user {
        animation-name: fade-in-up;
      }
    }
    .message-body {
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
      overflow-x: auto;
      padding: 0 var(--space-xl);
      margin: 0 calc(var(--space-xl) * -1);
    }
    .content {
      h1,
      h2,
      h3 {
        margin: 0 0 var(--space-md);
        line-height: 1.2;
      }
      p,
      ul,
      ol,
      pre,
      code,
      blockquote {
        margin: 0 0 var(--space-md);
        line-height: 1.4;
      }
      ul,
      ol {
        padding-left: 1.2em;
      }
      code {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace;
        background: color-mix(in srgb, var(--bot-message-bg), #000 5%);
        padding: 2px 4px;
        border-radius: 4px;
        font-size: 0.95em;
      }
      pre code {
        display: block;
        padding: var(--space-md);
        overflow-x: auto;
        white-space: pre;
      }
      blockquote {
        border-left: 4px solid var(--primary);
        padding-top: var(--space-md);
        padding-left: var(--space-md);
        padding-bottom: var(--space-md);
        background: color-mix(in srgb, var(--bot-message-bg), #000 3%);
        & > :last-child {
          margin-bottom: 0;
        }
      }
      img {
        max-width: 100%;
        max-height: 300px;
        border-radius: calc(var(--border-radius) / 2);
      }
      table {
        width: 100%;
        margin-bottom: var(--space-md);
        border: none;
        border-bottom: 4px solid var(--primary);
        border-radius: calc(var(--border-radius) / 1.6) calc(var(--border-radius) / 1.6) 0 0;
        border-collapse: separate;
        border-spacing: 0;
        overflow: hidden;
        background: var(--bot-message-bg);
        box-shadow:
          0 3px 8px rgba(0 0 0 / 12%),
          0 1.5px 3px rgba(0 0 0 / 8%);

        img {
          max-height: 150px;
        }

        .streaming & {
          table-layout: fixed;
        }
      }
      thead tr {
        background: var(--primary);
        color: var(--text-invert-color);
      }
      th,
      td {
        padding: calc(var(--space-xs) + 2px) var(--space-md);
        text-align: left;
      }
      th {
        font-weight: 600;
        position: relative;

        &:first-child {
          border-top-left-radius: calc(var(--border-radius) / 1.6);
        }
        &:last-child {
          border-top-right-radius: calc(var(--border-radius) / 1.6);
        }
      }
      tr {
        background: var(--bot-message-bg);

        & + tr {
          border-top: 1px solid var(--border-color);
        }
        &:nth-child(even) {
          background: color-mix(in srgb, var(--bot-message-bg), #000 4%);
        }
      }
      hr {
        border: none;
        border-top: 1px solid var(--border-color);
        margin: var(--space-md) 0;
      }
      a {
        color: var(--primary);
        text-decoration: none;
        &:hover {
          text-decoration: underline;
        }
      }
    }
    .message-role {
      position: absolute;
      right: var(--space-xl);
      bottom: -1.25em;
      color: var(--text-color);
      font-size: 0.85rem;
      opacity: 0.6;
    }
    .questions {
      margin: var(--space-md) 0;
      color: var(--primary);
      text-align: right;
    }
    .question-icon {
      vertical-align: middle;
      display: inline-block;
      height: 1.7rem;
      width: 1.7rem;
      margin-bottom: var(--space-xs);
      margin-left: var(--space-xs);
    }
    .question {
      position: relative;
      padding: var(--space-xs) var(--space-md);
      margin-bottom: var(--space-xs);
      margin-left: var(--space-xs);
      vertical-align: middle;
      color: var(--primary);
      background: var(--card-bg);
      border: 1px solid var(--primary);
      animation-name: fade-in-right;
      &:hover {
        background: color-mix(in srgb, var(--card-bg), var(--primary) 5%);
      }
    }
    .button,
    .submit-button, .location-button {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: var(--space-xs);
      border: var(--button-border);
      background: var(--submit-button-bg);
      color: var(--submit-button-color);
      &:disabled {
        color: var(--disabled-color);
      }
      &:hover:not(:disabled) {
        background: var(--submit-button-bg-hover);
      }
    }
    .submit-button {
      flex: 0 0 auto;
      padding: var(--space-xs);
      width: 36px;
      align-self: flex-end;
    }
    .location-button {
      flex: 0 0 auto;
      padding: var(--space-xs);
      width: 36px;
      height: 36px;
      align-self: center;
      color: var(--azc-text-subtle);
      border-radius: 50%;
      transition: all 0.2s ease;
    }
    .location-button.active {
      color: var(--primary);
      background-color: rgba(255, 87, 34, 0.1);
    }
    .location-button.loading {
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { opacity: 0.5; }
      50% { opacity: 1; }
      100% { opacity: 0.5; }
    }
    .error {
      color: var(--error-color);
      background: var(--error-bg);
      outline: var(--focus-outline) var(--error);

      & .message-body {
        flex-direction: row;
        align-items: center;
      }

      & button {
        flex: 0;
        padding: var(--space-md);
        color: var(--retry-button-color);
        background: var(--retry-button-bg);
        border: var(--retry-button-border);

        &:hover {
          background: var(--retry-button-bg-hover);
        }
      }
    }
    .error-message {
      flex: 1;
    }
    .chat-input {
      position: sticky;
      bottom: 0;
      padding: var(--space-xl);
      padding-top: var(--space-md);
      background: var(--bg);
      box-shadow: 0 calc(-1 * var(--space-md)) var(--space-md) var(--bg);
      display: flex;
      gap: var(--space-md);
    }
    .new-chat-button {
      flex: 0 0 auto;
      width: 48px;
      height: 48px;
      padding: var(--space-md);
      border-radius: 50%;
      background: var(--new-chat-button-bg);
      color: var(--new-chat-button-color);
      font-size: 1.5rem;
      &:hover:not(:disabled) {
        background: var(--new-chat-button-bg-hover);
        color: var(--new-chat-button-color);
      }
    }
    .input-form {
      display: flex;
      flex: 1 auto;
      background: var(--chat-input-bg);
      border: var(--chat-input-border);
      border-radius: var(--border-radius);
      padding: var(--space-md);
      box-shadow: var(--card-shadow);
      outline: var(--focus-outline) transparent;
      transition: outline 0.3s ease;
      overflow: hidden;

      &:has(.text-input:focus-visible) {
        outline: var(--focus-outline) var(--primary);
      }
    }
    .text-input {
      padding: var(--space-xs);
      font-family: inherit;
      font-size: 1rem;
      flex: 1 auto;
      height: 3rem;
      border: none;
      resize: none;
      background: none;
      &::placeholder {
        color: var(--text-color);
        opacity: 0.4;
      }
      &:focus {
        outline: none;
      }
      &:disabled {
        opacity: 0.7;
      }
    }
    .loader-animation {
      width: 100px;
      height: 4px;
      border-radius: var(--border-radius);
      overflow: hidden;
      background-color: var(--primary);
      transform: scaleX(0);
      transform-origin: center left;
      animation: cubic-bezier(0.85, 0, 0.15, 1) 2s infinite load-animation;
    }
    .current-step {
      font-size: 0.85rem;
      opacity: 0.7;
    }

    @keyframes load-animation {
      0% {
        transform: scaleX(0);
        transform-origin: center left;
      }
      50% {
        transform: scaleX(1);
        transform-origin: center left;
      }
      51% {
        transform: scaleX(1);
        transform-origin: center right;
      }
      100% {
        transform: scaleX(0);
        transform-origin: center right;
      }
    }
    @keyframes fade-in-up {
      0% {
        opacity: 0.5;
        top: 100px;
      }
      100% {
        opacity: 1;
        top: 0px;
      }
    }
    @keyframes fade-in-right {
      0% {
        opacity: 0.5;
        right: -100px;
      }
      100% {
        opacity: 1;
        right: 0;
      }
    }
    
    /* --- Toast Notifications --- */
    .toast-notification {
      position: fixed;
      bottom: 100px; /* Higher than input */
      left: 50%;
      transform: translateX(-50%) translateY(20px);
      background: rgba(33, 33, 33, 0.95);
      color: white;
      padding: 12px 24px;
      border-radius: 50px;
      font-size: 0.9rem;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      opacity: 0;
      transition: opacity 0.3s, transform 0.3s;
      z-index: 9999;
      pointer-events: none;
    }

    .toast-notification.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
    
    @media (prefers-reduced-motion: reduce) {
      .animation {
        animation: none;
      }
    }
  `;h([g({type:Object,converter:t=>({...Z,...JSON.parse(t??"{}")})})],p.prototype,"options",2);h([g()],p.prototype,"question",2);h([g({type:Array})],p.prototype,"messages",2);h([g()],p.prototype,"userId",2);h([g()],p.prototype,"sessionId",2);h([c()],p.prototype,"hasError",2);h([c()],p.prototype,"isLoading",2);h([c()],p.prototype,"isStreaming",2);h([c()],p.prototype,"currentStep",2);h([c()],p.prototype,"userLocation",2);h([c()],p.prototype,"isGettingLocation",2);h([c()],p.prototype,"toastMessage",2);h([P(".chat-container")],p.prototype,"chatContainerElement",2);h([P(".messages")],p.prototype,"messagesElement",2);h([P(".chat-input")],p.prototype,"chatInputElement",2);p=h([w("azc-chat")],p);const ft='<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M2 7.25C2 5.45507 3.45507 4 5.25 4H18.75C20.5449 4 22 5.45507 22 7.25V16.75C22 18.5449 20.5449 20 18.75 20H5.25C3.45508 20 2 18.5449 2 16.75V7.25ZM9.5 5.5V18.5H18.75C19.7165 18.5 20.5 17.7165 20.5 16.75V7.25C20.5 6.2835 19.7165 5.5 18.75 5.5H9.5ZM8 5.5H5.25C4.2835 5.5 3.5 6.2835 3.5 7.25V16.75C3.5 17.7165 4.2835 18.5 5.25 18.5H8V5.5Z"/></svg>',xt='<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10 5H14C14 3.89543 13.1046 3 12 3C10.8954 3 10 3.89543 10 5ZM8.5 5C8.5 3.067 10.067 1.5 12 1.5C13.933 1.5 15.5 3.067 15.5 5H21.25C21.6642 5 22 5.33579 22 5.75C22 6.16421 21.6642 6.5 21.25 6.5H19.9309L18.7589 18.6112C18.5729 20.5334 16.9575 22 15.0263 22H8.97369C7.04254 22 5.42715 20.5334 5.24113 18.6112L4.06908 6.5H2.75C2.33579 6.5 2 6.16421 2 5.75C2 5.33579 2.33579 5 2.75 5H8.5ZM10.5 9.75C10.5 9.33579 10.1642 9 9.75 9C9.33579 9 9 9.33579 9 9.75V17.25C9 17.6642 9.33579 18 9.75 18C10.1642 18 10.5 17.6642 10.5 17.25V9.75ZM14.25 9C14.6642 9 15 9.33579 15 9.75V17.25C15 17.6642 14.6642 18 14.25 18C13.8358 18 13.5 17.6642 13.5 17.25V9.75C13.5 9.33579 13.8358 9 14.25 9ZM6.73416 18.4667C6.84577 19.62 7.815 20.5 8.97369 20.5H15.0263C16.185 20.5 17.1542 19.62 17.2658 18.4667L18.4239 6.5H5.57608L6.73416 18.4667Z"/></svg>';var wt=Object.defineProperty,yt=Object.getOwnPropertyDescriptor,C=(t,e,r,o)=>{for(var a=o>1?void 0:o?yt(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&wt(e,r,a),a};const q={apiUrl:"",strings:{openSidebar:"Open sidebar",closeSidebar:"Close sidebar",chats:"Chats",deleteChatButton:"Delete chat",errorMessage:"Cannot load chat history",noChatHistory:"No chat history"}},A=()=>window.matchMedia("(width >= 800px)").matches;let v=class extends x{constructor(){super(...arguments),this.options=q,this.open=A(),this.userId="",this.chats=[],this.hasError=!1,this.isLoading=!1,this.getApiUrl=()=>this.options.apiUrl||"https://func-agent-api-lf6kch3t2wm3e.azurewebsites.net",this.renderLoader=()=>this.isLoading?i`<slot name="loader"><div class="loader-animation"></div></slot>`:l,this.renderNoChatHistory=()=>this.chats.length===0&&!this.isLoading&&!this.hasError?i`<div class="message">${this.options.strings.noChatHistory}</div>`:l,this.renderError=()=>this.hasError?i`<div class="message error">${this.options.strings.errorMessage}</div>`:l,this.renderPanelButton=t=>i`
    <button
      class="icon-button ${t?"panel-button":""}"
      @click=${this.onPanelClicked}
      title=${this.open?this.options.strings.closeSidebar:this.options.strings.openSidebar}
    >
      ${d(ft)}
    </button>
  `,this.renderChatEntry=t=>i`
    <a
      class="chat-entry"
      href="#"
      @click=${e=>{e.preventDefault(),this.onChatClicked(t.id)}}
      title=${t.title}
    >
      <span class="chat-title">${t.title}</span>
      <button
        class="icon-button"
        @click=${e=>{e.preventDefault(),e.stopPropagation(),this.onDeleteChatClicked(t.id)}}
        title="${this.options.strings.deleteChatButton}"
      >
        ${d(xt)}
      </button>
    </a>
  `}onPanelClicked(){this.open=!this.open}async onChatClicked(t){if(this.userId){try{this.isLoading=!0;const e=await fetch(`${this.getApiUrl()}/api/chats/${t}/?userId=${this.userId}`);if(!e.ok)throw new Error(`Failed to load chat: ${e.statusText}`);const r=await e.json(),o=new CustomEvent("loadSession",{detail:{id:t,messages:r},bubbles:!0});this.dispatchEvent(o),A()||(this.open=!1)}catch(e){console.error(e)}this.isLoading=!1}}async onDeleteChatClicked(t){if(this.userId)try{this.chats=this.chats.filter(e=>e.id!==t),await fetch(`${this.getApiUrl()}/api/chats/${t}?userId=${this.userId}`,{method:"DELETE"})}catch(e){console.error(e)}}requestUpdate(t,e){switch(t){case"userId":{this.userId&&this.refresh();break}case"chats":{const r=new CustomEvent("chatsUpdated",{detail:{chats:this.chats},bubbles:!0});this.dispatchEvent(r);break}case"hasError":case"isLoading":{const r={hasError:this.hasError,isLoading:this.isLoading},o=new CustomEvent("stateChanged",{detail:{state:r},bubbles:!0});this.dispatchEvent(o);break}}super.requestUpdate(t,e)}async refresh(){if(this.userId){this.isLoading=!0,this.hasError=!1;try{const t=await fetch(`${this.getApiUrl()}/api/chats?userId=${this.userId}`);if(!t.ok){if(t.status===400){console.warn("Chat history refresh skipped: Invalid User ID"),this.isLoading=!1;return}throw new Error(`API Error: ${t.status} ${t.statusText}`)}const e=await t.json();Array.isArray(e)?this.chats=e:(console.warn("Invalid chat history format:",e),this.chats=[])}catch(t){this.hasError=!0,console.error("Failed to refresh history:",t)}finally{this.isLoading=!1}}}render(){return i`<aside class="chats-panel">
        <div class="buttons">
          ${this.renderPanelButton()}
          <slot name="buttons"></slot>
        </div>
        <div class="chats">
          <h2>${this.options.strings.chats}</h2>
          ${this.renderLoader()} ${I(this.chats,t=>this.renderChatEntry(t))}
          ${this.renderNoChatHistory()} ${this.renderError()}
        </div>
      </aside>
      ${this.open?l:this.renderPanelButton(!0)} `}};v.styles=f`
    :host {
      /* Base properties */
      --primary: var(--azc-primary, #07f);
      --bg: var(--azc-bg, #eee);
      --error: var(--azc-error, #e30);
      --text-color: var(--azc-text-color, #000);
      --space-md: var(--azc-space-md, 12px);
      --space-xl: var(--azc-space-xl, calc(var(--space-md) * 2));
      --space-xs: var(--azc-space-xs, calc(var(--space-md) / 2));
      --space-xxs: var(--azc-space-xs, calc(var(--space-md) / 4));
      --border-radius: var(--azc-border-radius, 16px);
      --focus-outline: var(--azc-focus-outline, 2px solid);
      --overlay-color: var(--azc-overlay-color, rgba(0 0 0 / 40%));

      /* Component-specific properties */
      --panel-bg: var(--azc-panel-bg, #fff);
      --panel-width: var(--azc-panel-width, 300px);
      --panel-shadow: var(--azc-panel-shadow, 0 0 10px rgba(0, 0, 0, 0.1));
      --error-color: var(--azc-error-color, var(--error));
      --error-border: var(--azc-error-border, none);
      --error-bg: var(--azc-error-bg, var(--card-bg));
      --icon-button-color: var(--azc-icon-button-color, var(--text-color));
      --icon-button-bg: var(--azc-icon-button-bg, none);
      --icon-button-bg-hover: var(--azc-icon-button-bg, rgba(0, 0, 0, 0.07));
      --panel-button-color: var(--azc-panel-button-color, var(--text-color));
      --panel-button-bg: var(--azc-panel-button-bg, var(--bg));
      --panel-button-bg-hover: var(--azc-panel-button-bg, hsl(from var(--panel-button-bg) h s calc(l - 6)));
      --chat-entry-bg: var(--azc-chat-entry-bg, none);
      --chat-entry-bg-hover: var(--azc-chat-entry-bg-hover, #f0f0f0);

      width: 0;
      transition: width 0.3s ease;
      overflow: hidden;
    }
    :host([open]) {
      width: var(--panel-width);
    }
    :host(:not([open])) .panel-button {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      margin: var(--space-xs);
      background: var(--panel-button-bg);
      color: var(--panel-button-color);

      &:hover {
        background: var(--panel-button-bg-hover);
      }
    }
    @media (width < 800px) {
      :host([open]) {
        width: 0;

        & .chats-panel {
          left: 0;
        }
      }
      .chats-panel {
        position: absolute;
        top: 0;
        left: calc(var(--panel-width) * -1.2);
        z-index: 1;
        box-shadow: var(--panel-shadow);
        transition: left 0.3s ease;
      }
    }
    *:focus-visible {
      outline: var(--focus-outline) var(--primary);
    }
    .animation {
      animation: 0.3s ease;
    }
    svg {
      fill: currentColor;
      width: 100%;
    }
    button {
      font-size: 1rem;
      border-radius: calc(var(--border-radius) / 2);
      outline: var(--focus-outline) transparent;
      transition: outline 0.3s ease;

      &:not(:disabled) {
        cursor: pointer;
      }
    }
    h2 {
      margin: var(--space-md) 0 0 0;
      padding: var(--space-xs) var(--space-md);
      font-size: 0.9rem;
      font-weight: 600;
    }
    .buttons {
      display: flex;
      justify-content: space-between;
      padding: var(--space-xs);
      position: sticky;
      top: 0;
      background: var(--panel-bg);
      box-shadow: 0 var(--space-xs) var(--space-xs) var(--panel-bg);
    }
    .chats-panel {
      width: var(--panel-width);
      height: 100%;
      background: var(--panel-bg);
      font-family:
        'Segoe UI',
        -apple-system,
        BlinkMacSystemFont,
        Roboto,
        'Helvetica Neue',
        sans-serif;
      overflow: auto;
    }
    .chats {
      margin: 0;
      padding: 0;
      font-size: 0.9rem;
    }
    .chat-title {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
    .chat-entry {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: var(--space-xxs) var(--space-xxs) var(--space-xxs) var(--space-xs);
      margin: 0 var(--space-xs);
      border-radius: calc(var(--border-radius) / 2);
      color: var(--text-color);
      text-decoration: none;
      background: var(--chat-entry-bg);

      & .icon-button {
        flex: 0 0 auto;
        padding: var(--space-xxs);
        width: 28px;
        height: 28px;
      }

      &:hover {
        background: var(--chat-entry-bg-hover);
      }

      &:not(:focus):not(:hover) .icon-button:not(:focus) {
        opacity: 0;
      }
    }
    .message {
      padding: var(--space-xs) var(--space-md);
    }
    .error {
      color: var(--error-color);
    }
    .icon-button {
      width: 36px;
      height: 36px;
      padding: var(--space-xs);
      background: none;
      border: none;
      background: var(--icon-button-bg);
      color: var(--icon-button-color);
      font-size: 1.5rem;
      &:hover:not(:disabled) {
        background: var(--icon-button-bg-hover);
        color: var(--icon-button-color);
      }
    }
    .loader-animation {
      position: absolute;
      width: var(--panel-width);
      height: 2px;
      overflow: hidden;
      background-color: var(--primary);
      transform: scaleX(0);
      transform-origin: center left;
      animation: cubic-bezier(0.85, 0, 0.15, 1) 2s infinite load-animation;
    }

    @keyframes load-animation {
      0% {
        transform: scaleX(0);
        transform-origin: center left;
      }
      50% {
        transform: scaleX(1);
        transform-origin: center left;
      }
      51% {
        transform: scaleX(1);
        transform-origin: center right;
      }
      100% {
        transform: scaleX(0);
        transform-origin: center right;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      :host,
      .chats-panel {
        transition: none;
      }
      .animation {
        animation: none;
      }
    }
  `;C([g({type:Object,converter:t=>({...q,...JSON.parse(t??"{}")})})],v.prototype,"options",2);C([g({type:Boolean,reflect:!0})],v.prototype,"open",2);C([g()],v.prototype,"userId",2);C([c()],v.prototype,"chats",2);C([c()],v.prototype,"hasError",2);C([c()],v.prototype,"isLoading",2);v=C([w("azc-history")],v);const O="https://func-burger-api-lf6kch3t2wm3e.azurewebsites.net";async function Ct({userId:t,status:e,lastMinutes:r}){try{const o=new URLSearchParams;o.append("userId",t),e&&o.append("status",e),r&&o.append("last",`${r}m`);const a=`${O}/api/orders?${o.toString()}`,s=await fetch(a);return s.ok?await s.json():void 0}catch(o){console.error("Failed to fetch orders:",o);return}}function N(t){window.dispatchEvent(new CustomEvent("azc-view-change",{detail:{view:t}})),document.querySelectorAll(".view-section").forEach(e=>{e.classList.remove("active")}),document.getElementById(`view-${t}`)?.classList.add("active")}let T;async function L(t=!1){return!t&&T||(T=(async()=>(await(await fetch("/api/me")).json())?.id)()),T}async function kt(){try{const t=await L();if(!t)return;window.chatHistory&&(window.chatHistory.userId=t,window.chatHistory.addEventListener("loadSession",e=>{const{id:r,messages:o}=e.detail;window.chat&&(window.chat.sessionId=r,window.chat.messages=o,N("chat"))})),window.chat&&(window.chat.userId=t,window.chat.addEventListener("messagesUpdated",()=>{window.chatHistory&&window.chatHistory.refresh()}))}catch(t){console.log("Error initializing user session:",t)}}async function R(t){try{const e=await fetch(`${O}/api/wallet?userId=${t}`);return e.ok?await e.json():null}catch{return null}}async function G(t,e,r="crypto"){try{return await(await fetch(`${O}/api/wallet/deposit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:t,amount:e,type:r})})).json()}catch{return null}}const $t="/.auth/me";let M;async function H(t=!1){return!t&&M||(M=(async()=>(await(await fetch($t)).json())?.clientPrincipal)()),M}const W='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.7545 14.0002C18.9966 14.0002 20.0034 15.007 20.0034 16.2491V16.8245C20.0034 17.7188 19.6838 18.5836 19.1023 19.263C17.5329 21.0965 15.1457 22.0013 12.0004 22.0013C8.8545 22.0013 6.46849 21.0962 4.90219 19.2619C4.32242 18.583 4.00391 17.7195 4.00391 16.8267V16.2491C4.00391 15.007 5.01076 14.0002 6.25278 14.0002H17.7545ZM17.7545 15.5002H6.25278C5.83919 15.5002 5.50391 15.8355 5.50391 16.2491V16.8267C5.50391 17.3624 5.69502 17.8805 6.04287 18.2878C7.29618 19.7555 9.26206 20.5013 12.0004 20.5013C14.7387 20.5013 16.7063 19.7555 17.9627 18.2876C18.3117 17.8799 18.5034 17.361 18.5034 16.8245V16.2491C18.5034 15.8355 18.1681 15.5002 17.7545 15.5002ZM12.0004 2.00488C14.7618 2.00488 17.0004 4.24346 17.0004 7.00488C17.0004 9.76631 14.7618 12.0049 12.0004 12.0049C9.23894 12.0049 7.00036 9.76631 7.00036 7.00488C7.00036 4.24346 9.23894 2.00488 12.0004 2.00488ZM12.0004 3.50488C10.0674 3.50488 8.50036 5.07189 8.50036 7.00488C8.50036 8.93788 10.0674 10.5049 12.0004 10.5049C13.9334 10.5049 15.5004 8.93788 15.5004 7.00488C15.5004 5.07189 13.9334 3.50488 12.0004 3.50488Z"/></svg>',X='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.50215 11.4995C9.05562 11.4995 9.5043 11.9482 9.5043 12.5017C9.5043 13.0552 9.05562 13.5038 8.50215 13.5038C7.94868 13.5038 7.5 13.0552 7.5 12.5017C7.5 11.9482 7.94868 11.4995 8.50215 11.4995ZM12 4.3537V10.4995L12.0005 11.0045L19.442 11.0035L17.7196 9.27977C17.4534 9.01346 17.4292 8.59679 17.6471 8.30321L17.7198 8.21911C17.9861 7.95289 18.4027 7.92875 18.6963 8.14666L18.7804 8.21929L21.777 11.2169C22.043 11.483 22.0674 11.8992 21.85 12.1928L21.7775 12.2769L18.7809 15.2803C18.4884 15.5736 18.0135 15.5741 17.7203 15.2816C17.4537 15.0156 17.429 14.599 17.6465 14.3051L17.7191 14.2209L19.432 12.5035L12.0005 12.5045L12 19.2495C12 19.7159 11.5788 20.0692 11.1196 19.9881L2.61955 18.4868C2.26121 18.4235 2 18.1121 2 17.7482V5.74953C2 5.38222 2.26601 5.06896 2.62847 5.00944L11.1285 3.61361C11.5851 3.53863 12 3.89097 12 4.3537ZM10.5 5.2369L3.5 6.38641V17.1191L10.5 18.3555V5.2369ZM13 18.5008L13.7652 18.501L13.867 18.4941C14.2335 18.4443 14.5158 18.1299 14.5152 17.7497L14.508 13.4995H13V18.5008ZM13.002 9.99953L13 8.72487V4.99952L13.7453 4.99953C14.1245 4.99953 14.4381 5.28105 14.4883 5.64664L14.4953 5.74829L14.502 9.99953H13.002Z"/></svg>',zt='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" fill="#fff"><path d="M961 961H0V0h961v961zm1087 0h-961V0h961v961zM961 2048H0v-961h961v961zm1087 0h-961v-961h961v961z"/></svg>',Lt='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="#fff"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.976 0A7.977 7.977 0 0 0 0 7.976c0 3.522 2.3 6.507 5.431 7.584.392.049.538-.196.538-.392v-1.37c-2.201.49-2.69-1.076-2.69-1.076-.343-.93-.881-1.175-.881-1.175-.734-.489.048-.489.048-.489.783.049 1.224.832 1.224.832.734 1.223 1.859.88 2.3.685.048-.538.293-.88.489-1.076-1.762-.196-3.621-.881-3.621-3.964 0-.88.293-1.566.832-2.153-.05-.147-.343-.978.098-2.055 0 0 .685-.196 2.201.832.636-.196 1.322-.245 2.007-.245s1.37.098 2.006.245c1.517-1.027 2.202-.832 2.202-.832.44 1.077.146 1.908.097 2.104a3.16 3.16 0 0 1 .832 2.153c0 3.083-1.86 3.719-3.62 3.915.293.244.538.733.538 1.467v2.202c0 .196.146.44.538.392A7.984 7.984 0 0 0 16 7.976C15.951 3.572 12.38 0 7.976 0z"/></svg>';var St=Object.defineProperty,Et=Object.getOwnPropertyDescriptor,k=(t,e,r,o)=>{for(var a=o>1?void 0:o?Et(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&St(e,r,a),a};const Ft="/.auth/login",Tt="/.auth/logout",Q={strings:{logoutButton:"Log out"},providers:[{id:"aad",label:"Continue with Microsoft",icon:zt,color:"#2F2F2F",textColor:"#fff"},{id:"github",label:"Continue with GitHub",icon:Lt,color:"#24292e",textColor:"#fff"},{id:"google",label:"Continue with Google",icon:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512" fill="#fff"><path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/></svg>',color:"#4285F4",textColor:"#fff"}]};let m=class extends x{constructor(){super(...arguments),this.options=Q,this.type="login",this.loginRedirect="/",this.logoutRedirect="/",this.loaded=!1,this.renderStatus=()=>i`<section class="auth-status">
      <span class="login-icon">${d(W)}</span>
      ${this._userDetails?i`<span class="username">${this._userDetails.userDetails}</span>
            <slot name="logout"> ${this.renderLogout()} </slot>`:l}
    </section>`,this.renderGuard=()=>this.loaded&&this._userDetails?i`<slot></slot>`:l,this.renderLogin=()=>this.loaded?this.userDetails?l:this.renderLandingPage():i`<div class="loading-screen"><div class="spinner"></div></div>`,this.renderLandingPage=()=>i`
    <div class="landing-page">
      <div class="hero-section">
        <div class="hero-content">
          <div class="badge">✨ AI-Powered Cravings</div>
          <h1>Hungry? Just Ask <span class="highlight">Chicha</span>.</h1>
          <p class="subtitle">The first AI Agent that finds promos, schedules deliveries, and manages your orders across Uber, DoorDash, and POS systems.</p>

          <div class="social-proof">
            <div class="avatars">
              <div class="avatar" style="background-color: #FF6B6B">J</div>
              <div class="avatar" style="background-color: #4ECDC4">S</div>
              <div class="avatar" style="background-color: #FFE66D">M</div>
              <div class="avatar" style="background-color: #1A535C">+2k</div>
            </div>
            <div class="rating">
              ★★★★★ <span>Trusted by 10,000+ hungry humans</span>
            </div>
          </div>

          <button class="cta-button" @click=${()=>this.scrollToLogin()}>
            Order Now
          </button>
        </div>

        <div class="hero-visual">
           <div class="abstract-burger">
              <div class="bun-top"></div>
              <div class="lettuce"></div>
              <div class="patty"></div>
              <div class="bun-bottom"></div>
              <div class="float-card card-1">
                 <span>🎉</span> Promo Alert! 50% OFF
              </div>
              <div class="float-card card-2">
                 <span>🚚</span> Arriving in 5m
              </div>
           </div>
        </div>
      </div>

      <div class="login-section" id="login-target">
        <h2>Ready to eat?</h2>
        <p>Sign in to start your order</p>
        <div class="login-buttons">
          ${this.options.providers.map(t=>{const e={"--button-bg":t.color,"--button-color":t.textColor};return i`<button
              class="login-btn"
              @click=${()=>{this.onLoginClicked(t.id)}}
              style=${ot(e)}
            >
              <div class="btn-icon">${d(t.icon)}</div>
              <span>${t.label}</span>
            </button>`})}
        </div>
      </div>
    </div>
  `,this.renderLogout=()=>i`<button
      class="logout"
      @click=${()=>{this.onLogoutClicked()}}
      title="log out"
    >
      ${d(X)}
    </button>`}get userDetails(){return this._userDetails}onLoginClicked(t){const e=`${Ft}/${t}?post_login_redirect_uri=${encodeURIComponent(this.loginRedirect)}`;window.location.href=e}onLogoutClicked(){const t=`${Tt}?post_logout_redirect_uri=${encodeURIComponent(this.logoutRedirect)}`;window.location.href=t}scrollToLogin(){const t=this.renderRoot.querySelector("#login-target");t&&t.scrollIntoView({behavior:"smooth"})}async connectedCallback(){super.connectedCallback();const t=await H();this._userDetails=t,this.loaded=!0}updated(t){super.updated(t),this._userDetails?this.classList.add("authenticated"):this.classList.remove("authenticated")}render(){switch(this.type){case"status":return this.renderStatus();case"guard":return this.renderGuard();case"logout":return this.renderLogout();default:return this.renderLogin()}}};m.styles=f`
    :host {
      /* Critical fix: use contents so it doesn't block the grid layout of the body */
      display: contents;
      --azc-text-color-nav: #212121;
    }
    
    /* Hide host completely when authenticated in login mode to prevent overlay issues */
    :host(.authenticated[type="login"]) {
        display: none;
    }

    /* Loading State */
    .loading-screen {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      width: 100vw;
      position: fixed;
      top: 0;
      left: 0;
      background: white;
      z-index: 9999;
    }
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid rgba(0,0,0,0.1);
      border-left-color: var(--azc-primary);
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Authentication Status (Navbar) */
    .auth-status {
      display: flex;
      gap: 0.8rem;
      align-items: center;
      font-size: 0.9rem;
      font-weight: 600;
      color: #212121; /* Forced Black */
    }
    .login-icon {
      width: 24px;
      height: 24px;
      color: var(--azc-primary);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .username {
        display: block;
        max-width: 150px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: #000; /* Ensure visible */
    }
    /* High Contrast Logout Button */
    .logout {
      background: rgba(0,0,0,0.05);
      border: 1px solid transparent;
      cursor: pointer;
      padding: 8px;
      border-radius: 50%;
      color: #333333; /* Force dark color */
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
    }
    .logout:hover {
      background: #FF5722;
      color: #fff;
    }
    .logout svg {
      fill: currentColor;
      width: 18px;
      height: 18px;
    }

    /* --- Landing Page Styles --- */
    .landing-page {
      width: 100vw;
      height: 100vh;
      overflow-y: auto;
      background-color: var(--azc-bg);
      color: var(--azc-text-color);
      padding: 2rem;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      position: fixed;
      top: 0;
      left: 0;
      z-index: 9999;
    }

    /* Hero */
    .hero-section {
      display: flex;
      flex-direction: column-reverse;
      align-items: center;
      gap: 3rem;
      max-width: 1200px;
      width: 100%;
      margin: 2rem 0 4rem 0;
    }

    @media (min-width: 900px) {
      .hero-section {
        flex-direction: row;
        justify-content: space-between;
        text-align: left;
        height: 80vh;
        min-height: 600px;
      }
      .hero-content {
        flex: 1;
        padding-right: 2rem;
      }
      .hero-visual {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }

    .badge {
      display: inline-block;
      padding: 0.5rem 1rem;
      background: #FFF3E0;
      color: var(--azc-primary);
      border-radius: 50px;
      font-weight: 600;
      font-size: 0.85rem;
      margin-bottom: 1.5rem;
      border: 1px solid #FFE0B2;
    }

    h1 {
      font-size: 3rem;
      line-height: 1.1;
      font-weight: 800;
      margin: 0 0 1.5rem 0;
      letter-spacing: -0.02em;
    }

    .highlight {
      color: var(--azc-primary);
      position: relative;
    }

    .subtitle {
      font-size: 1.2rem;
      line-height: 1.6;
      color: var(--azc-text-subtle);
      margin-bottom: 2rem;
      max-width: 600px;
    }

    /* CTA Button */
    .cta-button {
      background: var(--azc-primary);
      color: white;
      border: none;
      padding: 1rem 2.5rem;
      font-size: 1.1rem;
      font-weight: 600;
      border-radius: 50px;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      box-shadow: 0 4px 14px rgba(255, 87, 34, 0.3);
    }
    .cta-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(255, 87, 34, 0.4);
      background: #F4511E;
    }

    /* Social Proof */
    .social-proof {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 2rem;
      flex-wrap: wrap;
    }
    .avatars {
      display: flex;
    }
    .avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      border: 2px solid white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.7rem;
      font-weight: bold;
      color: rgba(0,0,0,0.6);
      margin-left: -10px;
    }
    .avatar:first-child { margin-left: 0; }

    .rating {
      font-size: 0.9rem;
      font-weight: 600;
      color: #FFC107;
    }
    .rating span {
      color: var(--azc-text-subtle);
      font-weight: 400;
      margin-left: 5px;
    }

    /* Abstract Burger Visual */
    .abstract-burger {
      position: relative;
      width: 300px;
      height: 300px;
    }
    .bun-top {
      width: 200px;
      height: 100px;
      background: #FFD54F;
      border-radius: 200px 200px 20px 20px;
      position: absolute;
      top: 50px;
      left: 50px;
      box-shadow: inset -10px -5px 20px rgba(0,0,0,0.05);
    }
    .lettuce {
      width: 220px;
      height: 40px;
      background: #66BB6A;
      border-radius: 20px;
      position: absolute;
      top: 140px;
      left: 40px;
    }
    .patty {
      width: 200px;
      height: 50px;
      background: #795548;
      border-radius: 20px;
      position: absolute;
      top: 170px;
      left: 50px;
    }
    .bun-bottom {
      width: 200px;
      height: 60px;
      background: #FFD54F;
      border-radius: 20px 20px 50px 50px;
      position: absolute;
      top: 210px;
      left: 50px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }

    .float-card {
      position: absolute;
      background: white;
      padding: 0.8rem 1.2rem;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
      font-weight: 600;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      gap: 8px;
      animation: float 3s ease-in-out infinite;
    }
    .card-1 { top: 20px; right: -20px; animation-delay: 0s; }
    .card-2 { bottom: 40px; left: -40px; animation-delay: 1.5s; }

    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
      100% { transform: translateY(0px); }
    }

    /* Login Section */
    .login-section {
      background: white;
      padding: 3rem;
      border-radius: 24px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.08);
      text-align: center;
      max-width: 500px;
      width: 100%;
      margin-bottom: 4rem;
      scroll-margin-top: 100px;
    }

    .login-section h2 {
      margin: 0 0 0.5rem 0;
      font-size: 2rem;
    }
    .login-section p {
      color: var(--azc-text-subtle);
      margin: 0 0 2rem 0;
    }

    .login-buttons {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .login-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      width: 100%;
      padding: 14px 20px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      background: var(--button-bg);
      color: var(--button-color);
      transition: opacity 0.2s, transform 0.1s;
    }
    .login-btn:hover {
      opacity: 0.9;
    }
    .login-btn:active {
      transform: scale(0.98);
    }
    .btn-icon {
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .btn-icon svg {
      fill: currentColor;
      width: 100%;
      height: 100%;
    }
  `;k([g({type:Object,converter:t=>({...Q,...JSON.parse(t||"{}")})})],m.prototype,"options",2);k([g()],m.prototype,"type",2);k([g()],m.prototype,"loginRedirect",2);k([g()],m.prototype,"logoutRedirect",2);k([c()],m.prototype,"_userDetails",2);k([c()],m.prototype,"loaded",2);m=k([w("azc-auth")],m);const Mt='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.5028 4.62704L5.5 6.75V17.2542C5.5 19.0491 6.95507 20.5042 8.75 20.5042L17.3663 20.5045C17.0573 21.3782 16.224 22.0042 15.2444 22.0042H8.75C6.12665 22.0042 4 19.8776 4 17.2542V6.75C4 5.76929 4.62745 4.93512 5.5028 4.62704ZM17.75 2C18.9926 2 20 3.00736 20 4.25V17.25C20 18.4926 18.9926 19.5 17.75 19.5H8.75C7.50736 19.5 6.5 18.4926 6.5 17.25V4.25C6.5 3.00736 7.50736 2 8.75 2H17.75ZM17.75 3.5H8.75C8.33579 3.5 8 3.83579 8 4.25V17.25C8 17.6642 8.33579 18 8.75 18H17.75C18.1642 18 18.5 17.6642 18.5 17.25V4.25C18.5 3.83579 18.1642 3.5 17.75 3.5Z"/></svg>',It=`<?xml version="1.0" encoding="UTF-8"?><svg id="a" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M1.09,10.24c-.4-2.56,1.48-4.99,3.58-6.26,4.92-2.98,15.66-2.47,17.95,3.77.2.54.68,2.3.07,2.6l-20.86.08-.74-.18ZM11.83,3.98c-1.08.46-.6,1.13.12,1.66.34.26.83.58,1.2.21.66-.66-.63-1.79-1.31-1.87ZM8.02,4.99c-.95.04-2.06,2.09-.7,2.05.68-.02,2.18-1.73.7-2.05ZM16.76,5.53c-.64-.65-2.31.81-1.87,1.66.56.92,2.55-.96,1.87-1.66Z"/><path d="M22.94,16.63c.24.24.21,1.48.17,1.86-.14,1.65-.96,2.9-2.61,3.29H3.54c-2.52-.4-2.84-2.8-2.59-4.95l.62-.36h11.36c1.42.21,2.65,3.26,4.15,2.59.86-.38,2.09-2.31,2.8-2.53.41-.13,2.81-.14,3.07.11Z"/><path d="M10.45,12.13c2.13-.12,3.04,1.95,5.05,1.41.62-.17.99-.69,1.57-.96,1.09-.5,4.1-.71,5.24-.46.92.2.92,1.43,0,1.63-1,.22-2.48-.09-3.59.06-1.72.25-2.49,1.89-4.75,1.45-1.13-.22-2.29-1.53-3.43-1.49-1.44.05-2.59,1.7-4.5,1.55-1.48-.11-2.32-1.16-3.47-1.45-.6-.15-1.79.04-1.79-.87s1.34-.85,2-.74c1.31.22,2.21,1.47,3.69,1.38,1.33-.08,2.31-1.43,3.97-1.52Z"/></svg>
`,Y=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19.75 4C20.9926 4 22 5.00736 22 6.25V17.7546C22 18.9972 20.9926 20.0046 19.75 20.0046H4.25C3.00736 20.0046 2 18.9972 2 17.7546V6.25C2 5.00736 3.00736 4 4.25 4H19.75ZM19.75 5.5H4.25C3.83579 5.5 3.5 5.83579 3.5 6.25V17.7546C3.5 18.1688 3.83579 18.5046 4.25 18.5046H19.75C20.1642 18.5046 20.5 18.1688 20.5 17.7546V6.25C20.5 5.83579 20.1642 5.5 19.75 5.5ZM9.75 12.5C10.1642 12.5 10.5 12.8358 10.5 13.25V13.7427L10.4921 13.8513C10.3293 14.9642 9.39767 15.5009 7.99995 15.5009C6.60213 15.5009 5.67048 14.9637 5.50787 13.8501L5.5 13.7418V13.25C5.5 12.8358 5.83579 12.5 6.25 12.5H9.75ZM13.2523 12.9961H17.75C18.1642 12.9961 18.5 13.3319 18.5 13.7461C18.5 14.1258 18.2178 14.4396 17.8518 14.4893L17.75 14.4961H13.2523C12.8381 14.4961 12.5023 14.1604 12.5023 13.7461C12.5023 13.3664 12.7844 13.0526 13.1505 13.003L13.2523 12.9961H17.75H13.2523ZM8 8.50218C8.82841 8.50218 9.49997 9.17374 9.49997 10.0022C9.49997 10.8306 8.82841 11.5021 8 11.5021C7.17159 11.5021 6.50003 10.8306 6.50003 10.0022C6.50003 9.17374 7.17159 8.50218 8 8.50218ZM13.2523 9.5H17.75C18.1642 9.5 18.5 9.83579 18.5 10.25C18.5 10.6297 18.2178 10.9435 17.8518 10.9932L17.75 11H13.2523C12.8381 11 12.5023 10.6642 12.5023 10.25C12.5023 9.8703 12.7844 9.55651 13.1505 9.50685L13.2523 9.5H17.75H13.2523Z" /></svg>
`;var Ot=Object.defineProperty,_t=Object.getOwnPropertyDescriptor,b=(t,e,r,o)=>{for(var a=o>1?void 0:o?_t(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&Ot(e,r,a),a};let u=class extends x{constructor(){super(),this.userId="",this.isLoading=!1,this.hasError=!1,this.username="",this.isOpen=!1,this.activeTab="identity",this.orders=[],this.ordersLoading=!1,this.walletBalance={balance:0,cryptoBalance:0},this.walletLoading=!1,this.handleNavClick=()=>{this.openModal()},this.handleOverlayClick=t=>{t.target===t.currentTarget&&this.closeModal()},this.handleEscapeKey=t=>{t.key==="Escape"&&this.closeModal()},this.renderLoading=()=>i`<p class="message">Loading...</p>`,this.copyUserIdToClipboard=async()=>{if(this.userId)try{await navigator.clipboard.writeText(this.userId);const t=this.renderRoot.querySelector(".user-id");if(t){const e=document.createRange();e.selectNodeContents(t);const r=window.getSelection();r&&(r.removeAllRanges(),r.addRange(e))}}catch(t){console.error("Failed to copy user ID:",t)}},this.getUserId=async()=>{this.isLoading=!0,this.hasError=!1;try{const t=await H();if(!t)return;this.username=t.userDetails;const e=await L();if(!e)throw new Error("Unable to retrieve user ID");this.userId=e}catch(t){console.error("Error fetching user ID:",t),this.hasError=!0}finally{this.isLoading=!1}},this.renderIdentityTab=()=>i`
    <div class="card card-shine">
      <span class="burger">${d(It)}</span>
      <div class="card-content">
        <h1>Contoso Burgers</h1>
        <h2>Membership Card</h2>
        <p>Card attributed to:</p>
        <div><pre>${this.username}</pre></div>
        <p>Unique user ID:</p>
        <div class="user-id-row">
          <pre class="user-id">${this.userId}</pre>
          <button
            class="copy-button"
            @click="${this.copyUserIdToClipboard}"
            title="Copy user ID to clipboard"
            aria-label="Copy user ID to clipboard"
          >
            <span class="visually-hidden">Copy</span>
            <span class="copy-icon">${d(Mt)}</span>
          </button>
        </div>
        <div class="warning">This user ID is personal, do not share it with anyone!</div>
      </div>
    </div>
  `,this.renderOrdersTab=()=>i`
    <div class="orders-container">
        <h3>Order History</h3>
        ${this.ordersLoading?i`<div class="spinner"></div>`:l}
        ${!this.ordersLoading&&this.orders.length===0?i`<p class="empty-state">No orders found yet. Time to eat! 🍔</p>`:l}
        <div class="order-list">
            ${I(this.orders,t=>t.id,t=>i`
                <div class="order-item">
                    <div class="order-header">
                        <span class="order-date">${new Date(t.createdAt).toLocaleDateString()} ${new Date(t.createdAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</span>
                        <span class="order-status status-${t.status}">${t.status.replace("-"," ")}</span>
                    </div>
                    <div class="order-items">
                        ${t.items.length} Items • $${t.totalPrice.toFixed(2)}
                    </div>
                    <div class="order-id-small">#${t.id.slice(-6)}</div>
                </div>
            `)}
        </div>
    </div>
  `,this.renderWalletTab=()=>i`
    <div class="wallet-container">
        <h3>Chicha Wallet</h3>
        ${this.walletLoading?i`<div class="spinner"></div>`:i`
            <div class="wallet-card">
                 <div class="balance-section">
                     <span class="label">Available Balance</span>
                     <span class="balance">$${this.walletBalance.balance.toFixed(2)}</span>
                     <span class="sub-balance">${this.walletBalance.cryptoBalance.toFixed(6)} BTC</span>
                 </div>
                 <div class="wallet-actions">
                     <button class="wallet-btn primary" @click=${this.addFunds}>Add Funds (Simulate)</button>
                     <button class="wallet-btn">Manage Cards</button>
                 </div>
            </div>
    
            <div class="settlement-info">
                 <h4>Settlement Settings</h4>
                 <div class="setting-row">
                     <span>Merchant</span>
                     <strong>CoinGate Services</strong>
                 </div>
                 <div class="setting-row">
                     <span>Auto-Conversion</span>
                     <strong class="status-active">Enabled</strong>
                 </div>
                 <p class="info-text">Payments are processed via CoinGate and settled to Uber Eats in Fiat currency automatically.</p>
            </div>
        `}
    </div>
  `,this.renderNavLink=()=>i`
    <button @click="${this.handleNavClick}" class="member-card-link">
      <span class="card-icon">${d(Y)}</span>
      Dashboard
    </button>
  `,this.renderModal=()=>i`
    <div class="modal-overlay" @click="${this.handleOverlayClick}">
      <div class="modal-content">
        <div class="modal-header">
            <button class="close-button" @click="${this.closeModal}" aria-label="Close modal">×</button>
            <div class="tabs">
                <button class="tab ${this.activeTab==="identity"?"active":""}" @click=${()=>this.switchTab("identity")}>Identity</button>
                <button class="tab ${this.activeTab==="orders"?"active":""}" @click=${()=>this.switchTab("orders")}>Orders</button>
                <button class="tab ${this.activeTab==="wallet"?"active":""}" @click=${()=>this.switchTab("wallet")}>Wallet</button>
            </div>
        </div>
        <div class="modal-body">
            ${this.activeTab==="identity"?this.isLoading?this.renderLoading():this.renderIdentityTab():l}
            ${this.activeTab==="orders"?this.renderOrdersTab():l}
            ${this.activeTab==="wallet"?this.renderWalletTab():l}
        </div>
      </div>
    </div>
  `,this.getUserId()}openModal(){this.isOpen=!0,document.body.style.overflow="hidden",this.activeTab==="orders"?this.loadOrders():this.activeTab==="wallet"&&this.loadWallet()}closeModal(){this.isOpen=!1,document.body.style.overflow=""}switchTab(t){this.activeTab=t,t==="orders"?this.loadOrders():t==="wallet"&&this.loadWallet()}connectedCallback(){super.connectedCallback(),document.addEventListener("keydown",this.handleEscapeKey)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.handleEscapeKey),document.body.style.overflow=""}async loadOrders(){if(this.userId){this.ordersLoading=!0;try{const t=await Ct({userId:this.userId});t&&(this.orders=t.sort((e,r)=>r.createdAt.localeCompare(e.createdAt)))}catch(t){console.error("Failed to load orders",t)}finally{this.ordersLoading=!1}}}async loadWallet(){if(!this.userId)return;this.walletLoading=!0;const t=await R(this.userId);t&&(this.walletBalance=t),this.walletLoading=!1}async addFunds(){if(!this.userId)return;this.walletLoading=!0;const t=await G(this.userId,.0015,"crypto");t&&(this.walletBalance=t),this.walletLoading=!1}render(){return i` ${this.renderNavLink()} ${this.isOpen?this.renderModal():l} `}};u.styles=f`
    :host {
      --azc-primary: linear-gradient(135deg, #de471d 0%, #ff6b3d 100%);
      --azc-border-radius: 16px;
      --azc-text-color: #212121;
    }
    
    /* Nav Link Styles - High Contrast */
    .member-card-link {
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid #e0e0e0;
      color: #212121 !important; /* Forced dark color */
      text-decoration: none;
      padding: 0.6rem 1.2rem;
      border-radius: 50px;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
      font-family: inherit;
      font-size: 0.95rem;
      font-weight: 700;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    .member-card-link:hover {
      background: #fff;
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .card-icon {
      display: inline-block;
      fill: var(--azc-primary);
      width: 20px;
      height: 20px;
    }

    /* Modal Styles - Centering Fix and Contrast */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background-color: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(5px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2000;
    }
    .modal-content {
      position: relative;
      width: 90%;
      max-width: 700px;
      max-height: 90vh;
      background: #F9F9F9;
      border-radius: var(--azc-border-radius);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      color: #333;
      margin: auto;
    }
    .modal-header {
        background: white;
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #eee;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        flex-shrink: 0;
    }
    .close-button {
      position: absolute;
      top: 50%;
      right: 1rem;
      transform: translateY(-50%);
      background: none;
      border: none;
      font-size: 2rem;
      line-height: 1;
      cursor: pointer;
      color: #666;
      z-index: 10;
      padding: 0.5rem;
    }
    .close-button:hover { color: #000; }

    .tabs {
        display: flex;
        gap: 0.5rem;
        background: #f0f0f0;
        padding: 4px;
        border-radius: 8px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .tab {
        background: none;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        color: #666;
        transition: all 0.2s;
        font-size: 0.9rem;
    }
    .tab.active {
        background: white;
        color: #FF5722;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    .modal-body {
        flex: 1;
        overflow-y: auto;
        padding: 1.5rem;
        color: #333;
        min-height: 300px;
    }

    /* Identity Card Styles */
    svg {
      fill: currentColor;
      width: 100%;
    }
    h1 {
      font-size: 2em;
      color: #fff;
      margin: 0;
      font-weight: 600;
      text-transform: uppercase;
    }
    h1, h2 { font-family: 'Sofia Sans Condensed', sans-serif; }
    h1, h2, pre, .warning { text-shadow: 0 1px 0px rgba(0, 0, 0, 0.5); }
    
    .card {
      position: relative;
      background: var(--azc-primary);
      border-radius: var(--azc-border-radius);
      padding: 2rem;
      box-shadow: 0 10px 30px rgba(222, 71, 29, 0.3);
      font-family: 'Sofia Sans Condensed', sans-serif;
      text-align: left;
      width: 100%;
      box-sizing: border-box;
      color: #fff;
      font-size: 1.2rem;
    }
    .card h2 {
        font-size: 1em;
        margin: 0;
        font-weight: 600;
        font-style: italic;
        text-transform: uppercase;
    }
    .card pre {
        font-size: 1.5rem;
        font-weight: 600;
        margin: 0;
        white-space: normal;
        line-break: anywhere;
    }
    .card p { margin: 1.5rem 0 0 0; }
    
    .card-shine {
      --shine-deg: 45deg;
      position: relative;
      background-repeat: no-repeat;
      background-position: 0% 0, 0 0;
      background-image: linear-gradient(var(--shine-deg), transparent 20%, transparent 45%, #ffffff30 50%, #ffffff30 51%, transparent 56%, transparent 100%);
      background-size: 250% 250%, 100% 100%;
      transition: background-position 1.5s ease;
    }
    .card-shine:hover { background-position: 90% 0, 0 0; }
    
    .burger {
      z-index: 1;
      width: 10rem;
      height: 10rem;
      display: inline-block;
      vertical-align: middle;
      opacity: 0.4;
      position: absolute;
      right: -1rem;
      top: 3.5rem;
      pointer-events: none;
      clip-path: inset(0 1rem 0 0);
    }
    .user-id-row {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      border: 1px solid #ffffff;
      padding: 1rem;
      border-radius: calc(var(--azc-border-radius) / 2);
      margin: 0.5rem 0;
    }
    .copy-button {
      background: none;
      border: none;
      cursor: pointer;
      padding: 0.3rem;
      display: flex;
      align-items: center;
      border-radius: 4px;
      transition: background 0.2s;
    }
    .copy-button:hover { background: #ffffff30; }
    .copy-icon {
      width: 1.5rem;
      height: 1.5rem;
      display: inline-block;
      vertical-align: middle;
      color: #fff;
    }

    /* Orders Tab Styles */
    .orders-container h3, .wallet-container h3 {
        margin-top: 0;
        color: #333;
        border-bottom: 2px solid #FF5722;
        padding-bottom: 0.5rem;
        display: inline-block;
    }
    .order-list {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        margin-top: 1rem;
    }
    .order-item {
        background: white;
        border-radius: 12px;
        padding: 1rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        border: 1px solid #eee;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
    .order-date { font-size: 0.85rem; color: #888; }
    .order-status {
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        padding: 4px 8px;
        border-radius: 4px;
        background: #eee;
        color: #555;
    }
    .status-pending { background: #FFF3E0; color: #E65100; }
    .status-in-preparation { background: #E3F2FD; color: #1565C0; }
    .status-ready { background: #E8F5E9; color: #2E7D32; }
    .status-completed { background: #EEEEEE; color: #616161; }
    
    .order-items { font-weight: 600; font-size: 1.1rem; color: #333; }
    .order-id-small { font-size: 0.8rem; color: #aaa; font-family: monospace; }
    .empty-state { text-align: center; color: #888; margin-top: 2rem; font-style: italic; }
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid rgba(0,0,0,0.1);
      border-left-color: #FF5722;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 2rem auto;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Wallet Tab Styles */
    .wallet-card {
        background: linear-gradient(135deg, #1A1A1A 0%, #333 100%);
        color: white;
        border-radius: 16px;
        padding: 2rem;
        margin-bottom: 2rem;
        box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        text-align: center;
    }
    .balance-section { display: flex; flex-direction: column; align-items: center; margin-bottom: 2rem; }
    .balance-section .label { font-size: 0.9rem; opacity: 0.7; text-transform: uppercase; letter-spacing: 1px; }
    .balance-section .balance { font-size: 3rem; font-weight: 700; margin: 0.5rem 0; }
    .balance-section .sub-balance { font-family: monospace; opacity: 0.5; }
    
    .wallet-actions { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
    .wallet-btn {
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.2);
        color: white;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.2s;
    }
    .wallet-btn:hover { background: rgba(255,255,255,0.2); }
    .wallet-btn.primary { background: #FF5722; border-color: #FF5722; }
    .wallet-btn.primary:hover { background: #F4511E; }

    .settlement-info {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        border: 1px solid #eee;
    }
    .setting-row {
        display: flex;
        justify-content: space-between;
        padding: 0.8rem 0;
        border-bottom: 1px solid #f5f5f5;
    }
    .status-active { color: #4CAF50; }
    .info-text { font-size: 0.85rem; color: #888; margin-top: 1rem; line-height: 1.5; }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      border: 0;
    }
  `;b([c()],u.prototype,"userId",2);b([c()],u.prototype,"isLoading",2);b([c()],u.prototype,"hasError",2);b([c()],u.prototype,"username",2);b([c()],u.prototype,"isOpen",2);b([c()],u.prototype,"activeTab",2);b([c()],u.prototype,"orders",2);b([c()],u.prototype,"ordersLoading",2);b([c()],u.prototype,"walletBalance",2);b([c()],u.prototype,"walletLoading",2);u=b([w("azc-user-card")],u);const J='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 6V12L16 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',Dt='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.59 13.41L13.42 20.58C13.2343 20.766 13.0137 20.9135 12.7709 21.0141C12.5281 21.1147 12.2678 21.1665 12.005 21.1665C11.7422 21.1665 11.4819 21.1147 11.2391 21.0141C10.9963 20.9135 10.7757 20.766 10.59 20.58L2 12V2H12L20.59 10.59C20.9625 10.9647 21.1716 11.4716 21.1716 12C21.1716 12.5284 20.9625 13.0353 20.59 13.41V13.41Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 7H7.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';var Pt=Object.defineProperty,Ht=Object.getOwnPropertyDescriptor,_=(t,e,r,o)=>{for(var a=o>1?void 0:o?Ht(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&Pt(e,r,a),a};let z=class extends x{constructor(){super(...arguments),this.activeTab="chat",this.userInitials="",this.userPhoto=""}async connectedCallback(){super.connectedCallback(),window.addEventListener("azc-view-change",e=>{this.activeTab=e.detail.view});const t=await H();t?.userDetails&&(this.userInitials=t.userDetails.substring(0,2).toUpperCase())}switchTab(t){N(t)}openProfile(){const t=document.querySelector("azc-user-card");t&&t.openModal()}logout(){const t=document.querySelector("azc-auth");t&&t.onLogoutClicked()}render(){return i`
      <div class="brand">
        <img src="/favicon.png" alt="Chicha" />
      </div>

      <div class="nav-items">
        <button class="nav-item ${this.activeTab==="chat"?"active":""}" @click=${()=>this.switchTab("chat")} title="Chat">
          ${d(V)}
        </button>
        <button class="nav-item ${this.activeTab==="schedules"?"active":""}" @click=${()=>this.switchTab("schedules")} title="Schedules">
          ${d(J)}
        </button>
        <button class="nav-item ${this.activeTab==="promos"?"active":""}" @click=${()=>this.switchTab("promos")} title="Deals">
          ${d(Dt)}
        </button>
        <button class="nav-item ${this.activeTab==="wallet"?"active":""}" @click=${()=>this.switchTab("wallet")} title="Wallet">
          ${d(Y)}
        </button>
      </div>

      <div class="bottom-items">
        <button class="nav-item profile" @click=${this.openProfile} title="Profile">
           ${this.userPhoto?i`<img src="${this.userPhoto}" />`:i`<div class="avatar-placeholder">${this.userInitials||d(W)}</div>`}
        </button>
        <button class="nav-item logout" @click=${this.logout} title="Logout">
           ${d(X)}
        </button>
      </div>
    `}};z.styles=f`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      width: 100%;
      background: #FFFFFF;
      align-items: center;
      padding: 20px 0;
      box-sizing: border-box;
      border-right: 1px solid rgba(0,0,0,0.05);
    }

    .brand img {
        width: 40px;
        height: 40px;
        margin-bottom: 40px;
        filter: drop-shadow(0 4px 6px rgba(255, 87, 34, 0.2));
    }

    .nav-items {
        display: flex;
        flex-direction: column;
        gap: 20px;
        width: 100%;
        align-items: center;
        flex: 1;
    }

    .nav-item {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        border: none;
        background: transparent;
        color: #9E9E9E;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
    }

    .nav-item svg {
        width: 24px;
        height: 24px;
        fill: currentColor;
    }
    
    /* SVG fixes for stroke icons */
    .nav-item svg path[stroke] {
        fill: none;
    }

    .nav-item:hover {
        background: #F5F7FA;
        color: #FF5722;
    }

    .nav-item.active {
        background: #FFF3E0;
        color: #FF5722;
        box-shadow: 0 4px 12px rgba(255, 87, 34, 0.15);
    }

    .bottom-items {
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-top: auto;
    }

    .avatar-placeholder {
        width: 36px;
        height: 36px;
        background: #212121;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
    }
    
    .avatar-placeholder svg {
        width: 20px;
        height: 20px;
    }

    .logout:hover {
        color: #D32F2F;
        background: #FFEBEE;
    }
  `;_([c()],z.prototype,"activeTab",2);_([c()],z.prototype,"userInitials",2);_([c()],z.prototype,"userPhoto",2);z=_([w("azc-sidebar")],z);var Bt=Object.getOwnPropertyDescriptor,jt=(t,e,r,o)=>{for(var a=o>1?void 0:o?Bt(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=n(a)||a);return a};let D=class extends x{render(){return i`
      <div class="view-header">
        <h1>Scheduled Orders</h1>
        <p>Upcoming food drops tailored to your timeline.</p>
      </div>

      <div class="timeline">
         <div class="empty-state">
             <div class="icon">${d(J)}</div>
             <h3>No scheduled orders yet</h3>
             <p>Ask Chicha to "Order burgers for 8 PM" to see them here.</p>
         </div>
      </div>
    `}};D.styles=f`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
    .view-header {
        padding: 2rem;
        max-width: 800px;
        margin: 0 auto;
    }
    h1 { 
        font-family: 'Sofia Sans Condensed', sans-serif;
        font-size: 2.5rem; 
        margin: 0; 
        color: #212121;
        text-transform: uppercase;
    }
    p { color: #757575; margin-top: 0.5rem; }

    .timeline {
        max-width: 800px;
        margin: 2rem auto;
        padding: 0 2rem;
        position: relative;
    }

    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        background: white;
        border-radius: 24px;
        border: 2px dashed #eee;
    }
    .empty-state .icon {
        width: 64px;
        height: 64px;
        margin: 0 auto 1rem auto;
        color: #ddd;
    }
    .empty-state h3 { margin: 0; color: #333; }
  `;D=jt([w("azc-schedules")],D);var Ut=Object.defineProperty,At=Object.getOwnPropertyDescriptor,B=(t,e,r,o)=>{for(var a=o>1?void 0:o?At(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&Ut(e,r,a),a};let S=class extends x{constructor(){super(...arguments),this.promos=[],this.loading=!1}async connectedCallback(){super.connectedCallback(),this.loadPromos()}async loadPromos(){this.loading=!0;try{const t=await L();if(!t)return;const e=await fetch(`${O}/api/discovery/search?q=deals promo special cheap&userId=${t}`);if(e.ok){const r=await e.json();this.promos=r.results||[]}}catch(t){console.error(t)}finally{this.loading=!1}}render(){return i`
      <div class="view-header">
        <h1>Deal Hunter</h1>
        <p>AI-curated offers from Contoso Burgers and nearby partners.</p>
      </div>

      <div class="restaurant-grid">
          ${this.loading?i`<div class="spinner"></div>`:""}
          
          ${this.promos.map(t=>i`
             <div class="restaurant-card">
                 <div class="card-image" style="background-image: url('${t.image_url}')">
                    <span class="promo-badge">${t.promo||"Special Offer"}</span>
                 </div>
                 <div class="card-details">
                     <h4>${t.name}</h4>
                     <div class="meta">
                        <span>${t.source}</span>
                        <span class="rating" style="color:#FF5722"><strong>$${t.price}</strong></span>
                     </div>
                     <p style="font-size: 0.85rem; color: #666; margin-bottom: 10px; flex: 1;">${t.description}</p>
                     
                     ${t.type==="internal"?i`<button class="order-btn" @click=${()=>this.orderInternal(t.name)}>Order Now</button>`:i`<a href="${t.url}" target="_blank" class="order-btn">View on Uber Eats</a>`}
                 </div>
             </div>
          `)}
      </div>
    `}orderInternal(t){const e=new CustomEvent("azc-view-change",{detail:{view:"chat"}});window.dispatchEvent(e),setTimeout(()=>{const r=document.querySelector("azc-chat");r&&(r.question=`Order the ${t} promo`,r.onSendClicked())},100)}};S.styles=f`
    :host { display: block; width: 100%; height: 100%; }
    
    .view-header { padding: 2rem; max-width: 1200px; margin: 0 auto; }
    h1 { font-family: 'Sofia Sans Condensed', sans-serif; font-size: 2.5rem; margin: 0; color: #212121; text-transform: uppercase; }
    p { color: #757575; margin-top: 0.5rem; }

    .restaurant-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 20px;
      padding: 0 2rem 2rem 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    .restaurant-card {
      background: white;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      display: flex;
      flex-direction: column;
      border: 1px solid #eee;
      height: 100%;
      transition: transform 0.2s;
    }
    
    .restaurant-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }

    .card-image {
      height: 160px;
      background-size: cover;
      background-position: center;
      position: relative;
      background-color: #eee;
    }

    .promo-badge {
      position: absolute;
      top: 10px;
      left: 10px;
      background: #FF5722;
      color: white;
      font-size: 0.75rem;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 20px;
    }

    .card-details { padding: 16px; display: flex; flex-direction: column; flex: 1; }
    h4 { margin: 0 0 5px 0; font-size: 1.1rem; }
    .meta { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.9rem; color: #666; }
    
    .order-btn {
      margin-top: auto;
      display: block;
      text-align: center;
      background: #212121;
      color: white;
      text-decoration: none;
      padding: 10px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      border: none;
    }
    .spinner { margin: 2rem auto; width: 40px; height: 40px; border: 4px solid #eee; border-left-color: #FF5722; border-radius: 50%; animation: spin 1s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
  `;B([c()],S.prototype,"promos",2);B([c()],S.prototype,"loading",2);S=B([w("azc-promos")],S);var Vt=Object.defineProperty,Zt=Object.getOwnPropertyDescriptor,j=(t,e,r,o)=>{for(var a=o>1?void 0:o?Zt(e,r):e,s=t.length-1,n;s>=0;s--)(n=t[s])&&(a=(o?n(e,r,a):n(a))||a);return o&&a&&Vt(e,r,a),a};let E=class extends x{constructor(){super(...arguments),this.balance={balance:0,cryptoBalance:0},this.loading=!1}async connectedCallback(){super.connectedCallback(),this.loadWallet()}async loadWallet(){const t=await L();if(t){const e=await R(t);e&&(this.balance=e)}}async addFunds(){const t=await L();t&&(this.loading=!0,await G(t,.0015,"crypto"),await this.loadWallet(),this.loading=!1)}render(){return i`
      <div class="view-header">
        <h1>Universal Wallet</h1>
        <p>Manage crypto, fiat, and corporate cards in one place.</p>
      </div>

      <div class="wallet-layout">
          <!-- Main Balance Card -->
          <div class="balance-card">
              <div class="card-bg"></div>
              <div class="card-content">
                  <span class="label">Total Balance (USD Equiv)</span>
                  <div class="amount">$${this.balance.balance.toFixed(2)}</div>
                  <div class="crypto-amount">
                      <span>${this.balance.cryptoBalance.toFixed(6)} BTC</span>
                      <span class="separator">•</span>
                      <span>0.00 SOL</span>
                  </div>
                  <div class="actions">
                      <button class="action-btn primary" @click=${this.addFunds} ?disabled=${this.loading}>
                          ${this.loading?"Processing...":"Deposit Crypto"}
                      </button>
                      <button class="action-btn">Withdraw</button>
                  </div>
              </div>
          </div>

          <!-- Integration Grid -->
          <div class="integrations-grid">
              <div class="integration-item">
                  <div class="logo-area" style="background: #2196F3;">CG</div>
                  <div class="info">
                      <h4>CoinGate</h4>
                      <p>Crypto Payment Gateway</p>
                  </div>
                  <div class="status active">Connected</div>
              </div>
              
              <div class="integration-item">
                  <div class="logo-area" style="background: #673AB7;">K</div>
                  <div class="info">
                      <h4>Kast</h4>
                      <p>Corporate Cards</p>
                  </div>
                  <button class="connect-btn">Connect</button>
              </div>

              <div class="integration-item">
                  <div class="logo-area" style="background: #E91E63;">B</div>
                  <div class="info">
                      <h4>Bitrefill</h4>
                      <p>Gift Cards & Vouchers</p>
                  </div>
                  <button class="connect-btn">Connect</button>
              </div>
          </div>

          <!-- Transaction List placeholder -->
          <div class="transactions">
              <h3>Recent Activity</h3>
              <div class="tx-item">
                  <div class="tx-icon in">↓</div>
                  <div class="tx-info">
                      <div class="tx-title">Deposit (BTC)</div>
                      <div class="tx-date">Today, 10:23 AM</div>
                  </div>
                  <div class="tx-amount positive">+$100.00</div>
              </div>
              <div class="tx-item">
                  <div class="tx-icon out">↑</div>
                  <div class="tx-info">
                      <div class="tx-title">Uber Eats Settlement</div>
                      <div class="tx-date">Yesterday</div>
                  </div>
                  <div class="tx-amount negative">-$24.50</div>
              </div>
          </div>
      </div>
    `}};E.styles=f`
    :host { display: block; width: 100%; height: 100%; }
    .view-header { padding: 2rem; max-width: 800px; margin: 0 auto; }
    h1 { font-family: 'Sofia Sans Condensed', sans-serif; font-size: 2.5rem; margin: 0; color: #212121; text-transform: uppercase; }
    p { color: #757575; margin-top: 0.5rem; }

    .wallet-layout {
        max-width: 800px;
        margin: 0 auto;
        padding: 0 2rem 2rem 2rem;
    }

    .balance-card {
        background: #1a1a1a;
        border-radius: 24px;
        padding: 2rem;
        color: white;
        position: relative;
        overflow: hidden;
        margin-bottom: 2rem;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
    }
    
    .card-bg {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: linear-gradient(45deg, #FF5722, #FFC107);
        opacity: 0.1;
        z-index: 0;
    }
    
    .card-content { position: relative; z-index: 1; text-align: center; }
    .label { font-size: 0.9rem; opacity: 0.7; text-transform: uppercase; letter-spacing: 1px; }
    .amount { font-size: 3.5rem; font-weight: 700; margin: 10px 0; letter-spacing: -1px; }
    .crypto-amount { font-family: monospace; background: rgba(255,255,255,0.1); display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.9rem; margin-bottom: 2rem; }
    .separator { margin: 0 8px; opacity: 0.5; }
    
    .actions { display: flex; gap: 10px; justify-content: center; }
    .action-btn {
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.2);
        color: white;
        padding: 12px 24px;
        border-radius: 12px;
        font-weight: 600;
        cursor: pointer;
        font-size: 1rem;
        transition: all 0.2s;
    }
    .action-btn:hover { background: rgba(255,255,255,0.2); }
    .action-btn.primary { background: #FF5722; border-color: #FF5722; }
    .action-btn.primary:hover { background: #F4511E; }

    .integrations-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 2rem;
    }
    
    .integration-item {
        background: white;
        padding: 1rem;
        border-radius: 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        border: 1px solid #eee;
    }
    
    .logo-area {
        width: 40px; height: 40px;
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: 700; font-size: 0.9rem;
    }
    
    .info h4 { margin: 0; font-size: 1rem; }
    .info p { margin: 0; font-size: 0.75rem; color: #888; }
    
    .status.active { color: #4CAF50; font-size: 0.8rem; font-weight: 600; margin-left: auto; }
    .connect-btn {
        margin-left: auto;
        background: #f0f0f0;
        border: none;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 600;
        cursor: pointer;
    }

    .transactions h3 { margin-top: 0; font-size: 1.2rem; color: #333; }
    .tx-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px 0;
        border-bottom: 1px solid #eee;
    }
    .tx-icon {
        width: 36px; height: 36px;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
    }
    .tx-icon.in { background: #E8F5E9; color: #4CAF50; }
    .tx-icon.out { background: #FFEBEE; color: #F44336; }
    
    .tx-info { flex: 1; }
    .tx-title { font-weight: 600; color: #333; }
    .tx-date { font-size: 0.8rem; color: #888; }
    .tx-amount { font-weight: 700; }
    .positive { color: #4CAF50; }
    .negative { color: #333; }
  `;j([c()],E.prototype,"balance",2);j([c()],E.prototype,"loading",2);E=j([w("azc-wallet-view")],E);await kt();
//# sourceMappingURL=index-BrwEA6jL.js.map
